﻿

namespace CapaEntidad
{
    public class EntidadMembresia
    {
        public int opc { get; set; }
        public string ID_Membresia { get; set; }
        public String Tipo { get; set; }
        public int DuracionMeses { get; set; }
        public decimal Costo { get; set; }
        public String Beneficios { get; set; }
        public String Estado { get; set; }

    }
}
