﻿

namespace CapaEntidad
{
    public class EntidadFactura
    {
        public int opc { get; set; }
        public int ID_Factura { get; set; }
        public string Cedula_Cliente { get; set; }
        public DateTime FechaEmision { get; set; }
        public decimal MontoTotal { get; set; }
        public string MetodoPago { get; set; }
        public string Detalle { get; set; }
       public string ID_Membresia { get; set; }
       public string Estado { get; set; }
    }
}
