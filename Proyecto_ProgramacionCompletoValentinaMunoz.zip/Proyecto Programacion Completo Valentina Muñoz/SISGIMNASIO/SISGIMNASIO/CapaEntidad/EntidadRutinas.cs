﻿namespace CapaEntidad 
{
    public class EntidadRutinas
    {
        public int opc { get; set; }
        public string ID_Rutina { get; set; }
        public string ID_Empleados { get; set; }
        public string NombreRutina { get; set; }
        public string Descripcion { get; set; }
        public int DuracionSemanas { get; set; }
        public string Frecuencia { get; set; }
        public string NivelDificultad { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFin  { get; set; }
        public string Estado { get; set; }


    }
}
