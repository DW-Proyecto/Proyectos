
namespace CapaEntidad
{
    public class EntidadCliente

    {
        public int opc { get; set; }
        public string Cedula_Cliente { get; set; }
        public string Nombre1 { get; set; }
        public string Nombre2 { get; set; }
        public string AP1 { get; set; }
        public string AP2 { get; set; }
        public string Sexo { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public DateTime FechaIngreso { get; set; }
        public string ID_Membresia { get; set; }
        public string Estado { get; set; }
    }

}
