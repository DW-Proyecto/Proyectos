﻿

namespace CapaEntidad
{
    public class EntidadEmpleados
    {
        public int opc { get; set; }
        public String Cedula_Empleados { get; set; }
        public String ID_Empleado { get; set; }
        public String Nombre1 { get; set; }
        public String Nombre2 { get; set; }
        public String AP1 { get; set; }
        public String AP2 { get; set; }
        public String Sexo { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public DateTime FechaIngreso { get; set; }
        public String Especialidad { get; set; }
        public String Horario { get; set; }
    }
}
