﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocios
{
    public class EmpleadosHelper
    {
        #region Variables a utilizar
        Datos cnGeneral = null;
        EntidadEmpleados objEmpleados = null;
        DataTable tblDatos = null;
        #endregion

        #region Constructor de la Clase
        public EmpleadosHelper(EntidadEmpleados parObjEmpleados)
        {
            objEmpleados = parObjEmpleados; 
        }
        #endregion

        #region Listar todos los Empleados

        public DataTable ListarEmpleados()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[1];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objEmpleados.opc;
                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Empleados");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Listar por ID Empleados 
        public DataTable ListarIDEmpleados()

        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objEmpleados.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Empleado";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objEmpleados.ID_Empleado;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Empleados");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Insertar 
        public DataTable GuardarEmpleados()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[12];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = 3;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@Cedula_Empleados";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objEmpleados.Cedula_Empleados;

                parParameter[2] = new SqlParameter();
                parParameter[2].ParameterName = "@ID_Empleado";
                parParameter[2].SqlDbType = SqlDbType.VarChar;
                parParameter[2].Size = 30;
                parParameter[2].SqlValue = objEmpleados.ID_Empleado;

                parParameter[3] = new SqlParameter();
                parParameter[3].ParameterName = "@@Nombre1";
                parParameter[3].SqlDbType = SqlDbType.VarChar;
                parParameter[3].Size = 30;
                parParameter[3].SqlValue = objEmpleados.Nombre1;

                parParameter[4] = new SqlParameter();
                parParameter[4].ParameterName = "@Nombre2";
                parParameter[4].SqlDbType = SqlDbType.VarChar;
                parParameter[4].Size = 30;
                parParameter[4].SqlValue = objEmpleados.Nombre2;

                parParameter[5] = new SqlParameter();
                parParameter[5].ParameterName = "@AP1";
                parParameter[5].SqlDbType = SqlDbType.VarChar;
                parParameter[5].Size = 30;
                parParameter[5].SqlValue = objEmpleados.AP1;

                parParameter[6] = new SqlParameter();
                parParameter[6].ParameterName = "@AP2";
                parParameter[6].SqlDbType = SqlDbType.VarChar;
                parParameter[6].Size = 30;
                parParameter[6].SqlValue = objEmpleados.AP2;

                parParameter[7] = new SqlParameter();
                parParameter[7].ParameterName = "@Sexo";
                parParameter[7].SqlDbType = SqlDbType.VarChar;
                parParameter[7].Size = 30;
                parParameter[7].SqlValue = objEmpleados.Sexo;

                parParameter[8] = new SqlParameter();
                parParameter[8].ParameterName = "@FechaNacimiento";
                parParameter[8].SqlDbType = SqlDbType.Date;
                parParameter[8].SqlValue = objEmpleados.FechaNacimiento;

                parParameter[9] = new SqlParameter();
                parParameter[9].ParameterName = "@FechaIngreso";
                parParameter[9].SqlDbType = SqlDbType.Date;
                parParameter[9].SqlValue = objEmpleados.FechaIngreso;

                parParameter[10] = new SqlParameter();
                parParameter[10].ParameterName = "@Especialidad";
                parParameter[10].SqlDbType = SqlDbType.VarChar;
                parParameter[10].Size = 30;
                parParameter[10].SqlValue = objEmpleados.Especialidad;

                parParameter[11] = new SqlParameter();
                parParameter[11].ParameterName = "@Horario";
                parParameter[11].SqlDbType = SqlDbType.VarChar;
                parParameter[11].Size = 30;
                parParameter[11].SqlValue = objEmpleados.Horario;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Empleados"); ;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }
        #endregion

        #region Valida Codigo Empleados
        public DataTable ValidaCodigoEmpleados()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objEmpleados.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Empleados";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objEmpleados.ID_Empleado;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Empleados");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }


        #endregion

        #region Actualizar Cliente
        public void ActualizarEmpleados()
        {
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[12];

                parParameter[0] = new SqlParameter("@opc", SqlDbType.Int);
                parParameter[0].Value = objEmpleados.opc;

                parParameter[1] = new SqlParameter("@ID_Empleados", SqlDbType.VarChar, 30);
                parParameter[1].Value = objEmpleados.ID_Empleado;

                parParameter[2] = new SqlParameter("@Cedula_Empleados", SqlDbType.VarChar, 30);
                parParameter[2].Value = objEmpleados.Cedula_Empleados;

                parParameter[3] = new SqlParameter("@Nombre1", SqlDbType.VarChar, 30);
                parParameter[3].Value = objEmpleados.Nombre1;

                parParameter[4] = new SqlParameter("@Nombre2", SqlDbType.VarChar, 30);
                parParameter[4].Value = objEmpleados.Nombre2;

                parParameter[5] = new SqlParameter("@AP1", SqlDbType.VarChar, 30);
                parParameter[5].Value = objEmpleados.AP1;

                parParameter[6] = new SqlParameter("@AP2", SqlDbType.VarChar, 30);
                parParameter[6].Value = objEmpleados.AP2;

                parParameter[7] = new SqlParameter("@Sexo", SqlDbType.VarChar, 30);
                parParameter[7].Value = objEmpleados.Sexo;

                parParameter[8] = new SqlParameter("@FechaNacimiento", SqlDbType.Date);
                parParameter[8].Value = objEmpleados.FechaNacimiento;

                parParameter[9] = new SqlParameter("@FechaIngreso", SqlDbType.Date);
                parParameter[9].Value = objEmpleados.FechaIngreso;

                parParameter[10] = new SqlParameter("@Especialidad", SqlDbType.VarChar, 30);
                parParameter[10].Value = objEmpleados.Especialidad;

                parParameter[11] = new SqlParameter("@Horario", SqlDbType.VarChar, 30);
                parParameter[11].Value = objEmpleados.Horario;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Empleados");
            }
            catch (Exception ex)
            {
                throw new Exception("Error en ClienteHelper.Actualizar(): " + ex.Message);
            }
        }
        #endregion

        #region
        public void EliminarEmpleaados()
        {
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SISGimnasio;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("PA_Empleados", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@opc", objEmpleados.opc);
                cmd.Parameters.AddWithValue("@ID_Empleado", objEmpleados.ID_Empleado);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        #endregion



    }

}

    
