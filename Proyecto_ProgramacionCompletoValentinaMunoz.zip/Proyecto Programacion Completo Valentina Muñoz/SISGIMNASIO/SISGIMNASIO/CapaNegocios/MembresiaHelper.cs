﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocios
{
    public class MembresiaHelper
    {
        #region Variables a utilizar
        Datos cnGeneral = null;
        EntidadMembresia objMembresia = null;
        DataTable tblDatos = null;
        #endregion

        #region Constructor de la Clase
        public MembresiaHelper(EntidadMembresia parObjMembresia)
        {
            objMembresia = parObjMembresia;
        }
        #endregion

        #region Listar todas las Membresias
        public DataTable ListarMembresia()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[1];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objMembresia.opc;
                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Membresias");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Consultar por ID Membresia
        public DataTable ListarIDMembresia()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objMembresia.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Membresia";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objMembresia.ID_Membresia;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Membresias");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Insertar 
        public DataTable GuardarMembresia()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[7];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = 3;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Membresia";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objMembresia.ID_Membresia;

                parParameter[2] = new SqlParameter();
                parParameter[2].ParameterName = "@Tipo";
                parParameter[2].SqlDbType = SqlDbType.VarChar;
                parParameter[2].Size = 30;
                parParameter[2].SqlValue = objMembresia.Tipo;

                parParameter[3] = new SqlParameter();
                parParameter[3].ParameterName = "@DuracionMeses";
                parParameter[3].SqlDbType = SqlDbType.VarChar;
                parParameter[3].Size = 30;
                parParameter[3].SqlValue = objMembresia.DuracionMeses;

                parParameter[4] = new SqlParameter();
                parParameter[4].ParameterName = "@Costo";
                parParameter[4].SqlDbType = SqlDbType.Decimal;
                parParameter[4].Size = 30;
                parParameter[4].SqlValue = objMembresia.Costo;

                parParameter[5] = new SqlParameter();
                parParameter[5].ParameterName = "@Beneficios";
                parParameter[5].SqlDbType = SqlDbType.VarChar;
                parParameter[5].Size = 30;
                parParameter[5].SqlValue = objMembresia.Beneficios;

                parParameter[6] = new SqlParameter();
                parParameter[6].ParameterName = "@Estado";
                parParameter[6].SqlDbType = SqlDbType.VarChar;
                parParameter[6].Size = 30;
                parParameter[6].SqlValue = objMembresia.Estado;

                cnGeneral.RetornaTabla(parParameter, "PA_Membresias");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }
        #endregion

        #region Actualizar Membresia
        public void ActualizarMembresia()
        {
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[7];

                parParameter[0] = new SqlParameter("@opc", SqlDbType.Int);
                parParameter[0].Value = objMembresia.opc;

                parParameter[1] = new SqlParameter("@ID_Membresia", SqlDbType.VarChar, 30);
                parParameter[1].Value = objMembresia.ID_Membresia;

                parParameter[2] = new SqlParameter("@Tipo", SqlDbType.VarChar, 30);
                parParameter[2].Value = objMembresia.Tipo;

                parParameter[3] = new SqlParameter("@DuracionMeses", SqlDbType.Int);
                parParameter[3].Value = objMembresia.DuracionMeses;

                parParameter[4] = new SqlParameter("@Costo", SqlDbType.Decimal, 30);
                parParameter[4].Value = objMembresia.Costo;

                parParameter[5] = new SqlParameter("@Beneficios", SqlDbType.VarChar, 30);
                parParameter[5].Value = objMembresia.Beneficios;

                parParameter[6] = new SqlParameter("@Estado", SqlDbType.VarChar, 30);
                parParameter[6].Value = objMembresia.Estado;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Membresias");
            }
            catch (Exception ex)
            {
                throw new Exception("Error en MembresiaHelper.Actualizar(): " + ex.Message);
            }
        }
        #endregion

        #region
        public void EliminarMembresia()
        {
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SISGimnasio;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("PA_Membresias", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@opc", objMembresia.opc);
                cmd.Parameters.AddWithValue("@ID_Membresia", objMembresia.ID_Membresia);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        #endregion


        #region Valida Codigo Membresia
        public DataTable ValidaCodigoMembresia()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objMembresia.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Membresia";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].SqlValue = objMembresia.ID_Membresia;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Membresias");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }


        #endregion


    }
}
