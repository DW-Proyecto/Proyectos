﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocios
{
    public class FacturaHelper
    {
        #region Variables a utilizar
        Datos cnGeneral = null;
        EntidadFactura objFactura = null;
        DataTable tblDatos = null;
        #endregion
    

       #region Constructor de la Clase
        public FacturaHelper(EntidadFactura parObjFactura)
        {
            objFactura = parObjFactura;
        }
        #endregion

        #region Listar todas las facturas 

        public DataTable ListarFacturas()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[1];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;

                parParameter[0].SqlValue = objFactura.opc;
                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Factura");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Listar Factura por Cliente  
        public DataTable ListarFacturaporCliente()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objFactura.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@Cedula_Cliente";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objFactura.Cedula_Cliente;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Insertar 
        public DataTable GuardarFactura()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[8];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = 3;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Factura";
                parParameter[1].SqlDbType = SqlDbType.Int;
                parParameter[1].SqlValue = objFactura.ID_Factura;

                parParameter[2] = new SqlParameter();
                parParameter[2].ParameterName = "@Cedula_Cliente";
                parParameter[2].SqlDbType = SqlDbType.VarChar;
                parParameter[2].Size = 30;
                parParameter[2].SqlValue = objFactura.Cedula_Cliente;


                parParameter[3] = new SqlParameter();
                parParameter[3].ParameterName = "FechaEmision";
                parParameter[3].SqlDbType = SqlDbType.Date;
                parParameter[3].SqlValue = objFactura.FechaEmision;

                parParameter[4] = new SqlParameter();
                parParameter[4].ParameterName = "@MontoTotal";
                parParameter[4].SqlDbType = SqlDbType.Decimal;
                parParameter[4].Size = 30;
                parParameter[4].SqlValue = objFactura.MontoTotal;

                parParameter[5] = new SqlParameter();
                parParameter[5].ParameterName = "@MetodoPago";
                parParameter[5].SqlDbType = SqlDbType.VarChar;
                parParameter[5].Size = 30;
                parParameter[5].SqlValue = objFactura.MetodoPago;

                parParameter[6] = new SqlParameter();
                parParameter[6].ParameterName = "@Detalle";
                parParameter[6].SqlDbType = SqlDbType.VarChar;
                parParameter[6].Size = 30;
                parParameter[6].SqlValue = objFactura.Detalle;

                parParameter[7] = new SqlParameter();
                parParameter[7].ParameterName = "@ID_Membresia";
                parParameter[7].SqlDbType = SqlDbType.VarChar;
                parParameter[7].Size = 50; 
                parParameter[7].SqlValue = objFactura.ID_Membresia;

                cnGeneral.RetornaTabla(parParameter, "PA_Factura");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }
        #endregion

        #region Actualizar Factura
        public void ActualizarFactura()
        {
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[8];

                parParameter[0] = new SqlParameter("@opc", SqlDbType.Int);
                parParameter[0].Value = objFactura.opc;

                parParameter[1] = new SqlParameter("@ID_Factura", SqlDbType.Int);
                parParameter[1].Value = objFactura.ID_Factura;

                parParameter[2] = new SqlParameter("@Cedula_Cliente", SqlDbType.VarChar, 30);
                parParameter[2].Value = objFactura.Cedula_Cliente;

                parParameter[3] = new SqlParameter("@FechaEmision", SqlDbType.Date);
                parParameter[3].Value = objFactura.FechaEmision;

                parParameter[4] = new SqlParameter("@MontoTotal", SqlDbType.Decimal);
                parParameter[4].Precision = 18;
                parParameter[4].Scale = 2;
                parParameter[4].Value = objFactura.MontoTotal;

                parParameter[5] = new SqlParameter("@MetodoPago", SqlDbType.VarChar, 30);
                parParameter[5].Value = objFactura.MetodoPago;

                parParameter[6] = new SqlParameter("@Detalle", SqlDbType.VarChar, 200); // más espacio
                parParameter[6].Value = objFactura.Detalle;

                parParameter[7] = new SqlParameter("@ID_Membresia", SqlDbType.VarChar, 30);
                parParameter[7].Value = objFactura.ID_Membresia;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Factura");
            }
            catch (Exception ex)
            {
                throw new Exception("Error en FacturaHelper.Actualizar(): " + ex.Message);
            }
        }
        #endregion

        #region Eliminar
        public void EliminarFactura()
        {
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SISGimnasio;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("PA_Factura", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@opc", objFactura.opc);
                cmd.Parameters.AddWithValue("@Cedula_Cliente", objFactura.Cedula_Cliente);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        #endregion

        #region Valida Codigo Factura
        public DataTable ValidaCodigoFactura()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objFactura.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Factura";
                parParameter[1].SqlDbType = SqlDbType.Int;
                parParameter[1].SqlValue = objFactura.ID_Factura;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Factura");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

    }
    #endregion
}