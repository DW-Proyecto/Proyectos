﻿using CapaDatos;
using CapaEntidad;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocios
{
    public class RutinasHelper
    {
        #region Variables a utilizar
        Datos cnGeneral = null;
        EntidadRutinas objRutinas = null;
        DataTable tblDatos = null;
        #endregion

        #region Constructor de la Clase
        public RutinasHelper(EntidadRutinas parObjRutinas)
        {
            objRutinas = parObjRutinas;
        }
        #endregion


        #region Actualizar Rutina
        public void ActualizarRutina()
        {
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[11];

                parParameter[0] = new SqlParameter("@opc", SqlDbType.Int);
                parParameter[0].Value = objRutinas.opc;

                parParameter[1] = new SqlParameter("@ID_Rutina", SqlDbType.VarChar, 30);
                parParameter[1].Value = objRutinas.ID_Rutina;

                parParameter[2] = new SqlParameter("@ID_Empleado", SqlDbType.VarChar, 30);
                parParameter[2].Value = objRutinas.ID_Empleados;

                parParameter[3] = new SqlParameter("@NombreRutina", SqlDbType.VarChar, 30);
                parParameter[3].Value = objRutinas.NombreRutina;

                parParameter[4] = new SqlParameter("@Descripcion", SqlDbType.VarChar, 30);
                parParameter[4].Value = objRutinas.Descripcion;

                parParameter[5] = new SqlParameter("@DuracionSemanas", SqlDbType.Int);
                parParameter[5].Value = objRutinas.DuracionSemanas;

                parParameter[6] = new SqlParameter("@Frecuencia", SqlDbType.VarChar, 30);
                parParameter[6].Value = objRutinas.Frecuencia;

                parParameter[7] = new SqlParameter("@NivelDificultad", SqlDbType.VarChar,30);
                parParameter[7].Value = objRutinas.NivelDificultad;

                parParameter[8] = new SqlParameter("@FechaInicio", SqlDbType.Date);
                parParameter[8].Value = objRutinas.FechaInicio;

                parParameter[9] = new SqlParameter("@FechaFin", SqlDbType.Date);
                parParameter[9].Value = objRutinas.FechaFin;

                parParameter[10] = new SqlParameter("@Estado", SqlDbType.VarChar, 30);
                parParameter[10].Value = objRutinas.Estado;

                

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Rutinas");
            }
            catch (Exception ex)
            {
                throw new Exception("Error en RutinaHelper.Actualizar(): " + ex.Message);
            }
        }
        #endregion

        #region
        public void EliminarRutina()
        {
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SISGimnasio;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("PA_Rutinas", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@opc", objRutinas.opc);
                cmd.Parameters.AddWithValue("@ID_Rutina", objRutinas.ID_Rutina);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        #endregion


        #region Listar todas las Rutinas

        public DataTable ListarRutinas()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[1];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objRutinas.opc;
                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Rutinas");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Listar Rutina por numero de cedula 
        public bool ValidaCliente()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objRutinas.opc;



                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");

                return tblDatos != null && tblDatos.Rows.Count > 0;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
    
        }

        #endregion

        #region Insertar 
        public DataTable GuardarRutina()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[11];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = 3;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Rutina";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objRutinas.ID_Rutina;

                parParameter[2] = new SqlParameter();
                parParameter[2].ParameterName = "@ID_Empleados";
                parParameter[2].SqlDbType = SqlDbType.VarChar;
                parParameter[2].Size = 30;
                parParameter[2].SqlValue = objRutinas.ID_Empleados;

                parParameter[3] = new SqlParameter();
                parParameter[3].ParameterName = "@NombreRutina";
                parParameter[3].SqlDbType = SqlDbType.VarChar;
                parParameter[3].Size = 30;
                parParameter[3].SqlValue = objRutinas.NombreRutina;

                parParameter[4] = new SqlParameter();
                parParameter[4].ParameterName = "@Descripcion";
                parParameter[4].SqlDbType = SqlDbType.VarChar;
                parParameter[4].Size = 30;
                parParameter[4].SqlValue = objRutinas.Descripcion;

                parParameter[5] = new SqlParameter();
                parParameter[5].ParameterName = "@DuracionSemanas";
                parParameter[5].SqlDbType = SqlDbType.Int;
                parParameter[5].SqlValue = objRutinas.DuracionSemanas;

                parParameter[6] = new SqlParameter();
                parParameter[6].ParameterName = "@Frecuencia";
                parParameter[6].SqlDbType = SqlDbType.VarChar;
                parParameter[6].Size = 30;
                parParameter[6].SqlValue = objRutinas.Frecuencia;

                parParameter[7] = new SqlParameter();
                parParameter[7].ParameterName = "@NivelDificultad";
                parParameter[7].SqlDbType = SqlDbType.VarChar;
                parParameter[7].Size = 30;
                parParameter[7].SqlValue = objRutinas.NivelDificultad;

                parParameter[8] = new SqlParameter();
                parParameter[8].ParameterName = "@FechaInicio";
                parParameter[8].SqlDbType = SqlDbType.Date;
                parParameter[8].SqlValue = objRutinas.FechaInicio;

                parParameter[9] = new SqlParameter();
                parParameter[9].ParameterName = "@FechaFin";
                parParameter[9].SqlDbType = SqlDbType.Date;
                parParameter[9].SqlValue = objRutinas.FechaFin;

                parParameter[10] = new SqlParameter();
                parParameter[10].ParameterName = "@Estado";
                parParameter[10].SqlDbType = SqlDbType.VarChar;
                parParameter[10].Size = 30;
                parParameter[10].SqlValue = objRutinas.Estado;

                cnGeneral.RetornaTabla(parParameter, "PA_Rutinas");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }
        #endregion

        #region Valida Codigo
        public DataTable ValidaRutina()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objRutinas.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@ID_Rutina";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objRutinas.ID_Rutina;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Rutinas");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }


        #endregion
    }
}
