using System.Data.SqlClient;
using CapaEntidad;
using CapaDatos;
using System.Data;

namespace CapaNegocios
{
    public class ClienteHelper
    {
        #region Variables a utilizar
        Datos cnGeneral = null;
        EntidadCliente objCliente = null;
        DataTable tblDatos = null;
        #endregion

        #region Constructor de la Clase
        public ClienteHelper(EntidadCliente parObjCliente)
        {
            objCliente = parObjCliente;
        }
        #endregion

        #region Listar todos los Clientes
      
        public DataTable Listar()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[1];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objCliente.opc;
                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Listar por Numero de cedula 
        public DataTable ListarClientesPorCedula()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objCliente.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@Cedula_Cliente";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objCliente.Cedula_Cliente;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }

        #endregion

        #region Insertar 
        public DataTable GuardarClientes()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[11];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = 3;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@Cedula_Cliente";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objCliente.Cedula_Cliente;

                parParameter[2] = new SqlParameter();
                parParameter[2].ParameterName = "@Nombre1";
                parParameter[2].SqlDbType = SqlDbType.VarChar;
                parParameter[2].Size = 30;
                parParameter[2].SqlValue = objCliente.Nombre1;

                parParameter[3] = new SqlParameter();
                parParameter[3].ParameterName = "@Nombre2";
                parParameter[3].SqlDbType = SqlDbType.VarChar;
                parParameter[3].Size = 30;
                parParameter[3].SqlValue = objCliente.Nombre2;

                parParameter[4] = new SqlParameter();
                parParameter[4].ParameterName = "@AP1";
                parParameter[4].SqlDbType = SqlDbType.VarChar;
                parParameter[4].Size = 30;
                parParameter[4].SqlValue = objCliente.AP1;

                parParameter[5] = new SqlParameter();
                parParameter[5].ParameterName = "@AP2";
                parParameter[5].SqlDbType = SqlDbType.VarChar;
                parParameter[5].Size = 30;
                parParameter[5].SqlValue = objCliente.AP2;

                parParameter[6] = new SqlParameter();
                parParameter[6].ParameterName = "@Sexo";
                parParameter[6].SqlDbType = SqlDbType.VarChar;
                parParameter[6].Size = 30;
                parParameter[6].SqlValue = objCliente.Sexo;

                parParameter[7] = new SqlParameter();
                parParameter[7].ParameterName = "@FechaNacimiento";
                parParameter[7].SqlDbType = SqlDbType.Date;
                parParameter[7].Size = 30;
                parParameter[7].SqlValue = objCliente.FechaNacimiento;

                parParameter[8] = new SqlParameter();
                parParameter[8].ParameterName = "@FechaIngreso";
                parParameter[8].SqlDbType = SqlDbType.Date;
                parParameter[8].Size = 30;
                parParameter[8].SqlValue = objCliente.FechaIngreso;

                parParameter[9] = new SqlParameter();
                parParameter[9].ParameterName = "@ID_Membresia";
                parParameter[9].SqlDbType = SqlDbType.VarChar;
                parParameter[9].Size = 50;
                parParameter[9].SqlValue = objCliente.ID_Membresia;

                parParameter[10] = new SqlParameter();
                parParameter[10].ParameterName = "@Estado";
                parParameter[10].SqlDbType = SqlDbType.VarChar;
                parParameter[10].Size = 20;
                parParameter[10].SqlValue = objCliente.Estado;

                cnGeneral.RetornaTabla(parParameter, "PA_Clientes");



                return tblDatos;  

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
           
        }
        #endregion

        #region Valida Codigo
        public DataTable ValidaCodigo()
        {
            tblDatos = new DataTable();

            try
            {
                cnGeneral = new Datos();
                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = objCliente.opc;

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@Cedula_Cliente";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objCliente.Cedula_Cliente;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }


        #endregion

        #region Activar Cliente
        public DataTable ActivarCliente()
        {
            tblDatos = new DataTable();
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[2];

                parParameter[0] = new SqlParameter();
                parParameter[0].ParameterName = "@opc";
                parParameter[0].SqlDbType = SqlDbType.Int;
                parParameter[0].SqlValue = 5;  // OPC para activar un cliente

                parParameter[1] = new SqlParameter();
                parParameter[1].ParameterName = "@Cedula_Cliente";
                parParameter[1].SqlDbType = SqlDbType.VarChar;
                parParameter[1].Size = 30;
                parParameter[1].SqlValue = objCliente.Cedula_Cliente;  // Cedula del cliente a activar

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return tblDatos;
        }
        #endregion

        #region Actualizar Cliente
        public void ActualizarCliente()
        {
            try
            {
                cnGeneral = new Datos();

                SqlParameter[] parParameter = new SqlParameter[11];

                parParameter[0] = new SqlParameter("@opc", SqlDbType.Int);
                parParameter[0].Value = objCliente.opc;

                parParameter[1] = new SqlParameter("@Cedula_Cliente", SqlDbType.VarChar, 30);
                parParameter[1].Value = objCliente.Cedula_Cliente;

                parParameter[2] = new SqlParameter("@Nombre1", SqlDbType.VarChar, 30);
                parParameter[2].Value = objCliente.Nombre1;

                parParameter[3] = new SqlParameter("@Nombre2", SqlDbType.VarChar, 30);
                parParameter[3].Value = objCliente.Nombre2;

                parParameter[4] = new SqlParameter("@AP1", SqlDbType.VarChar, 30);
                parParameter[4].Value = objCliente.AP1;

                parParameter[5] = new SqlParameter("@AP2", SqlDbType.VarChar, 30);
                parParameter[5].Value = objCliente.AP2;

                parParameter[6] = new SqlParameter("@Sexo", SqlDbType.VarChar, 30);
                parParameter[6].Value = objCliente.Sexo;

                parParameter[7] = new SqlParameter("@FechaNacimiento", SqlDbType.Date);
                parParameter[7].Value = objCliente.FechaNacimiento;

                parParameter[8] = new SqlParameter("@FechaIngreso", SqlDbType.Date);
                parParameter[8].Value = objCliente.FechaIngreso;

                parParameter[9] = new SqlParameter("@ID_Membresia", SqlDbType.VarChar, 30);
                parParameter[9].Value = objCliente.ID_Membresia;

                parParameter[10] = new SqlParameter("@Estado", SqlDbType.VarChar, 30);
                parParameter[10].Value = objCliente.Estado;

                tblDatos = cnGeneral.RetornaTabla(parParameter, "PA_Clientes");
            }
            catch (Exception ex)
            {
                throw new Exception("Error en ClienteHelper.Actualizar(): " + ex.Message);
            }
        }
        #endregion

        #region
        public void EliminarCliente()
        {
            using (SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=SISGimnasio;Integrated Security=True"))
            {
                SqlCommand cmd = new SqlCommand("PA_Clientes", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@opc", objCliente.opc);
                cmd.Parameters.AddWithValue("@Cedula_Cliente", objCliente.Cedula_Cliente);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
        #endregion



    }

}
