﻿namespace Presentacion
{
    partial class FrmMembresias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioButtonBusacrMembresia = new RadioButton();
            radioButtonActualizarMmebresia = new RadioButton();
            radioButtonIngresarMembresia = new RadioButton();
            radioButtonEliminarMembresia = new RadioButton();
            labelTipoMmebresia = new Label();
            labelDuracionMeses = new Label();
            labelCostoMmebresia = new Label();
            labelBeneficioMembresia = new Label();
            radioButtonMembresiaBasica = new RadioButton();
            radioButtonMmebresiaPremium = new RadioButton();
            radioButtonMembresiaVIP = new RadioButton();
            textBoxDuracionMembresia = new TextBox();
            textBoxCostoMembresia = new TextBox();
            textBoxBeneficioMembresia = new TextBox();
            dataGridViewMembresias = new DataGridView();
            buttonAceptarMembresia = new Button();
            buttonCancelarMembresia = new Button();
            labelMembresias = new Label();
            labelIDMembresia = new Label();
            textBoxIDMembresia = new TextBox();
            groupBoxTipoMembresia = new GroupBox();
            groupBoxSeleccionMembresia = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMembresias).BeginInit();
            groupBoxTipoMembresia.SuspendLayout();
            groupBoxSeleccionMembresia.SuspendLayout();
            SuspendLayout();
            // 
            // radioButtonBusacrMembresia
            // 
            radioButtonBusacrMembresia.AutoSize = true;
            radioButtonBusacrMembresia.Location = new Point(6, 15);
            radioButtonBusacrMembresia.Name = "radioButtonBusacrMembresia";
            radioButtonBusacrMembresia.Size = new Size(60, 19);
            radioButtonBusacrMembresia.TabIndex = 0;
            radioButtonBusacrMembresia.TabStop = true;
            radioButtonBusacrMembresia.Text = "Buscar";
            radioButtonBusacrMembresia.UseVisualStyleBackColor = true;
            // 
            // radioButtonActualizarMmebresia
            // 
            radioButtonActualizarMmebresia.AutoSize = true;
            radioButtonActualizarMmebresia.Location = new Point(145, 15);
            radioButtonActualizarMmebresia.Name = "radioButtonActualizarMmebresia";
            radioButtonActualizarMmebresia.Size = new Size(77, 19);
            radioButtonActualizarMmebresia.TabIndex = 1;
            radioButtonActualizarMmebresia.TabStop = true;
            radioButtonActualizarMmebresia.Text = "Actualizar";
            radioButtonActualizarMmebresia.UseVisualStyleBackColor = true;
            radioButtonActualizarMmebresia.CheckedChanged += radioButtonActualizarMmebresia_CheckedChanged;
            // 
            // radioButtonIngresarMembresia
            // 
            radioButtonIngresarMembresia.AutoSize = true;
            radioButtonIngresarMembresia.Location = new Point(72, 15);
            radioButtonIngresarMembresia.Name = "radioButtonIngresarMembresia";
            radioButtonIngresarMembresia.Size = new Size(67, 19);
            radioButtonIngresarMembresia.TabIndex = 2;
            radioButtonIngresarMembresia.TabStop = true;
            radioButtonIngresarMembresia.Text = "Ingresar";
            radioButtonIngresarMembresia.UseVisualStyleBackColor = true;
            // 
            // radioButtonEliminarMembresia
            // 
            radioButtonEliminarMembresia.AutoSize = true;
            radioButtonEliminarMembresia.Location = new Point(228, 15);
            radioButtonEliminarMembresia.Name = "radioButtonEliminarMembresia";
            radioButtonEliminarMembresia.Size = new Size(68, 19);
            radioButtonEliminarMembresia.TabIndex = 3;
            radioButtonEliminarMembresia.TabStop = true;
            radioButtonEliminarMembresia.Text = "Eliminar";
            radioButtonEliminarMembresia.UseVisualStyleBackColor = true;
            // 
            // labelTipoMmebresia
            // 
            labelTipoMmebresia.AutoSize = true;
            labelTipoMmebresia.Location = new Point(308, 135);
            labelTipoMmebresia.Name = "labelTipoMmebresia";
            labelTipoMmebresia.Size = new Size(108, 15);
            labelTipoMmebresia.TabIndex = 4;
            labelTipoMmebresia.Text = "Tipo de Membresia";
            // 
            // labelDuracionMeses
            // 
            labelDuracionMeses.AutoSize = true;
            labelDuracionMeses.Location = new Point(309, 173);
            labelDuracionMeses.Name = "labelDuracionMeses";
            labelDuracionMeses.Size = new Size(107, 15);
            labelDuracionMeses.TabIndex = 5;
            labelDuracionMeses.Text = "Duracion en Meses";
            // 
            // labelCostoMmebresia
            // 
            labelCostoMmebresia.AutoSize = true;
            labelCostoMmebresia.Location = new Point(341, 205);
            labelCostoMmebresia.Name = "labelCostoMmebresia";
            labelCostoMmebresia.Size = new Size(38, 15);
            labelCostoMmebresia.TabIndex = 6;
            labelCostoMmebresia.Text = "Costo";
            // 
            // labelBeneficioMembresia
            // 
            labelBeneficioMembresia.AutoSize = true;
            labelBeneficioMembresia.Location = new Point(341, 242);
            labelBeneficioMembresia.Name = "labelBeneficioMembresia";
            labelBeneficioMembresia.Size = new Size(56, 15);
            labelBeneficioMembresia.TabIndex = 7;
            labelBeneficioMembresia.Text = "Beneficio";
            // 
            // radioButtonMembresiaBasica
            // 
            radioButtonMembresiaBasica.AutoSize = true;
            radioButtonMembresiaBasica.Location = new Point(6, 0);
            radioButtonMembresiaBasica.Name = "radioButtonMembresiaBasica";
            radioButtonMembresiaBasica.Size = new Size(58, 19);
            radioButtonMembresiaBasica.TabIndex = 8;
            radioButtonMembresiaBasica.TabStop = true;
            radioButtonMembresiaBasica.Text = "Basica";
            radioButtonMembresiaBasica.UseVisualStyleBackColor = true;
            // 
            // radioButtonMmebresiaPremium
            // 
            radioButtonMmebresiaPremium.AutoSize = true;
            radioButtonMmebresiaPremium.Location = new Point(95, 0);
            radioButtonMmebresiaPremium.Name = "radioButtonMmebresiaPremium";
            radioButtonMmebresiaPremium.Size = new Size(74, 19);
            radioButtonMmebresiaPremium.TabIndex = 9;
            radioButtonMmebresiaPremium.TabStop = true;
            radioButtonMmebresiaPremium.Text = "Premium";
            radioButtonMmebresiaPremium.UseVisualStyleBackColor = true;
            // 
            // radioButtonMembresiaVIP
            // 
            radioButtonMembresiaVIP.AutoSize = true;
            radioButtonMembresiaVIP.Location = new Point(219, 4);
            radioButtonMembresiaVIP.Name = "radioButtonMembresiaVIP";
            radioButtonMembresiaVIP.Size = new Size(42, 19);
            radioButtonMembresiaVIP.TabIndex = 10;
            radioButtonMembresiaVIP.TabStop = true;
            radioButtonMembresiaVIP.Text = "VIP";
            radioButtonMembresiaVIP.UseVisualStyleBackColor = true;
            // 
            // textBoxDuracionMembresia
            // 
            textBoxDuracionMembresia.Location = new Point(439, 170);
            textBoxDuracionMembresia.Name = "textBoxDuracionMembresia";
            textBoxDuracionMembresia.Size = new Size(341, 23);
            textBoxDuracionMembresia.TabIndex = 11;
            // 
            // textBoxCostoMembresia
            // 
            textBoxCostoMembresia.Location = new Point(439, 205);
            textBoxCostoMembresia.Name = "textBoxCostoMembresia";
            textBoxCostoMembresia.Size = new Size(339, 23);
            textBoxCostoMembresia.TabIndex = 12;
            // 
            // textBoxBeneficioMembresia
            // 
            textBoxBeneficioMembresia.Location = new Point(439, 234);
            textBoxBeneficioMembresia.Name = "textBoxBeneficioMembresia";
            textBoxBeneficioMembresia.Size = new Size(339, 23);
            textBoxBeneficioMembresia.TabIndex = 13;
            // 
            // dataGridViewMembresias
            // 
            dataGridViewMembresias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMembresias.Location = new Point(246, 303);
            dataGridViewMembresias.Name = "dataGridViewMembresias";
            dataGridViewMembresias.Size = new Size(652, 269);
            dataGridViewMembresias.TabIndex = 14;
            // 
            // buttonAceptarMembresia
            // 
            buttonAceptarMembresia.Location = new Point(513, 274);
            buttonAceptarMembresia.Name = "buttonAceptarMembresia";
            buttonAceptarMembresia.Size = new Size(75, 23);
            buttonAceptarMembresia.TabIndex = 15;
            buttonAceptarMembresia.Text = "Aceptar";
            buttonAceptarMembresia.UseVisualStyleBackColor = true;
            buttonAceptarMembresia.Click += buttonAceptarMembresia_Click;
            // 
            // buttonCancelarMembresia
            // 
            buttonCancelarMembresia.Location = new Point(631, 274);
            buttonCancelarMembresia.Name = "buttonCancelarMembresia";
            buttonCancelarMembresia.Size = new Size(69, 22);
            buttonCancelarMembresia.TabIndex = 16;
            buttonCancelarMembresia.Text = "Cancelar";
            buttonCancelarMembresia.UseVisualStyleBackColor = true;
            // 
            // labelMembresias
            // 
            labelMembresias.AutoSize = true;
            labelMembresias.BackColor = SystemColors.ButtonFace;
            labelMembresias.Font = new Font("Castellar", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelMembresias.Location = new Point(504, 27);
            labelMembresias.Name = "labelMembresias";
            labelMembresias.Size = new Size(165, 25);
            labelMembresias.TabIndex = 17;
            labelMembresias.Text = "Membresias";
            // 
            // labelIDMembresia
            // 
            labelIDMembresia.AutoSize = true;
            labelIDMembresia.Location = new Point(334, 106);
            labelIDMembresia.Name = "labelIDMembresia";
            labelIDMembresia.Size = new Size(82, 15);
            labelIDMembresia.TabIndex = 18;
            labelIDMembresia.Text = "ID_Membresia";
            // 
            // textBoxIDMembresia
            // 
            textBoxIDMembresia.Location = new Point(439, 106);
            textBoxIDMembresia.Name = "textBoxIDMembresia";
            textBoxIDMembresia.Size = new Size(339, 23);
            textBoxIDMembresia.TabIndex = 19;
            // 
            // groupBoxTipoMembresia
            // 
            groupBoxTipoMembresia.Controls.Add(radioButtonMembresiaBasica);
            groupBoxTipoMembresia.Controls.Add(radioButtonMmebresiaPremium);
            groupBoxTipoMembresia.Controls.Add(radioButtonMembresiaVIP);
            groupBoxTipoMembresia.Location = new Point(439, 135);
            groupBoxTipoMembresia.Name = "groupBoxTipoMembresia";
            groupBoxTipoMembresia.Size = new Size(341, 29);
            groupBoxTipoMembresia.TabIndex = 20;
            groupBoxTipoMembresia.TabStop = false;
            // 
            // groupBoxSeleccionMembresia
            // 
            groupBoxSeleccionMembresia.BackColor = Color.Transparent;
            groupBoxSeleccionMembresia.Controls.Add(radioButtonBusacrMembresia);
            groupBoxSeleccionMembresia.Controls.Add(radioButtonIngresarMembresia);
            groupBoxSeleccionMembresia.Controls.Add(radioButtonActualizarMmebresia);
            groupBoxSeleccionMembresia.Controls.Add(radioButtonEliminarMembresia);
            groupBoxSeleccionMembresia.Location = new Point(12, 12);
            groupBoxSeleccionMembresia.Name = "groupBoxSeleccionMembresia";
            groupBoxSeleccionMembresia.Size = new Size(307, 40);
            groupBoxSeleccionMembresia.TabIndex = 21;
            groupBoxSeleccionMembresia.TabStop = false;
            groupBoxSeleccionMembresia.Enter += groupBoxSeleccionMembresia_Enter;
            // 
            // FrmMembresias
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(1108, 608);
            Controls.Add(groupBoxSeleccionMembresia);
            Controls.Add(groupBoxTipoMembresia);
            Controls.Add(textBoxIDMembresia);
            Controls.Add(labelIDMembresia);
            Controls.Add(labelMembresias);
            Controls.Add(buttonCancelarMembresia);
            Controls.Add(buttonAceptarMembresia);
            Controls.Add(dataGridViewMembresias);
            Controls.Add(textBoxBeneficioMembresia);
            Controls.Add(textBoxCostoMembresia);
            Controls.Add(textBoxDuracionMembresia);
            Controls.Add(labelBeneficioMembresia);
            Controls.Add(labelCostoMmebresia);
            Controls.Add(labelDuracionMeses);
            Controls.Add(labelTipoMmebresia);
            Name = "FrmMembresias";
            Text = "Sistema Gimnasio-Membresias";
            Load += FrmMembresias_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewMembresias).EndInit();
            groupBoxTipoMembresia.ResumeLayout(false);
            groupBoxTipoMembresia.PerformLayout();
            groupBoxSeleccionMembresia.ResumeLayout(false);
            groupBoxSeleccionMembresia.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButtonBusacrMembresia;
        private RadioButton radioButtonActualizarMmebresia;
        private RadioButton radioButtonIngresarMembresia;
        private RadioButton radioButtonEliminarMembresia;
        private Label labelTipoMmebresia;
        private Label labelDuracionMeses;
        private Label labelCostoMmebresia;
        private Label labelBeneficioMembresia;
        private RadioButton radioButtonMembresiaBasica;
        private RadioButton radioButtonMmebresiaPremium;
        private RadioButton radioButtonMembresiaVIP;
        private TextBox textBoxDuracionMembresia;
        private TextBox textBoxCostoMembresia;
        private TextBox textBoxBeneficioMembresia;
        private DataGridView dataGridViewMembresias;
        private Button buttonAceptarMembresia;
        private Button buttonCancelarMembresia;
        private Label labelMembresias;
        private Label labelIDMembresia;
        private TextBox textBoxIDMembresia;
        private GroupBox groupBoxTipoMembresia;
        private GroupBox groupBoxSeleccionMembresia;
    }
}