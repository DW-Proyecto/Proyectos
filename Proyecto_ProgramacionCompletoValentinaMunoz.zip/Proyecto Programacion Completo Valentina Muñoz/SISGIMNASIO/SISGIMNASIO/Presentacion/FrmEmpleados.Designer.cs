﻿namespace Presentacion
{
    partial class FrmEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelCedulaEmpleados = new Label();
            labelID_Empleados = new Label();
            labelNombre1Empleados = new Label();
            labelNombre2Empleados = new Label();
            labelAP1Empleados = new Label();
            label6 = new Label();
            imageList1 = new ImageList(components);
            labelAP2Empleados = new Label();
            labelSexoEmpleados = new Label();
            labelFechaNacimientoEmpleados = new Label();
            label1FechaIngresoEmpleados = new Label();
            labelHorarioEmpleados = new Label();
            radioButtonBuscarEmpleados = new RadioButton();
            radioButtonActualizarEmpleados = new RadioButton();
            radioButtonIngresarEmpleados = new RadioButton();
            radioButtonEliminarEmpleados = new RadioButton();
            dateTimePickerFechaNacimientoEmpleados = new DateTimePicker();
            dateTimePickerFechaIngresoEmpleados = new DateTimePicker();
            dataGridViewEmpleados = new DataGridView();
            buttonAceptarEmpleados = new Button();
            buttonCancelarEmpleados = new Button();
            label1 = new Label();
            textBoxCedulaEmpleados = new TextBox();
            textBoxIDEmpleados = new TextBox();
            textBoxNombre1Empleados = new TextBox();
            textBoxNombre2Empleados = new TextBox();
            textBoxAP1Empleados = new TextBox();
            textBoxAP2Empleados = new TextBox();
            textBoxEspecialidadEmpleados = new TextBox();
            textBoxHorarioEmpleados = new TextBox();
            textBoxSexoEmpleados = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEmpleados).BeginInit();
            SuspendLayout();
            // 
            // labelCedulaEmpleados
            // 
            labelCedulaEmpleados.AutoSize = true;
            labelCedulaEmpleados.Location = new Point(37, 111);
            labelCedulaEmpleados.Name = "labelCedulaEmpleados";
            labelCedulaEmpleados.Size = new Size(44, 15);
            labelCedulaEmpleados.TabIndex = 0;
            labelCedulaEmpleados.Text = "Cedula";
            // 
            // labelID_Empleados
            // 
            labelID_Empleados.AutoSize = true;
            labelID_Empleados.Location = new Point(163, 111);
            labelID_Empleados.Name = "labelID_Empleados";
            labelID_Empleados.Size = new Size(76, 15);
            labelID_Empleados.TabIndex = 1;
            labelID_Empleados.Text = "ID_Empleado";
            // 
            // labelNombre1Empleados
            // 
            labelNombre1Empleados.AutoSize = true;
            labelNombre1Empleados.Location = new Point(279, 111);
            labelNombre1Empleados.Name = "labelNombre1Empleados";
            labelNombre1Empleados.Size = new Size(89, 15);
            labelNombre1Empleados.TabIndex = 2;
            labelNombre1Empleados.Text = "Primer Nombre";
            // 
            // labelNombre2Empleados
            // 
            labelNombre2Empleados.AutoSize = true;
            labelNombre2Empleados.Location = new Point(421, 111);
            labelNombre2Empleados.Name = "labelNombre2Empleados";
            labelNombre2Empleados.Size = new Size(101, 15);
            labelNombre2Empleados.TabIndex = 3;
            labelNombre2Empleados.Text = "Segundo Nombre";
            // 
            // labelAP1Empleados
            // 
            labelAP1Empleados.AutoSize = true;
            labelAP1Empleados.Location = new Point(565, 111);
            labelAP1Empleados.Name = "labelAP1Empleados";
            labelAP1Empleados.Size = new Size(89, 15);
            labelAP1Empleados.TabIndex = 4;
            labelAP1Empleados.Text = "Primer Apellido";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(861, 111);
            label6.Name = "label6";
            label6.Size = new Size(72, 15);
            label6.TabIndex = 5;
            label6.Text = "Especialidad";
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth32Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // labelAP2Empleados
            // 
            labelAP2Empleados.AutoSize = true;
            labelAP2Empleados.Location = new Point(696, 111);
            labelAP2Empleados.Name = "labelAP2Empleados";
            labelAP2Empleados.Size = new Size(101, 15);
            labelAP2Empleados.TabIndex = 6;
            labelAP2Empleados.Text = "Segundo Apellido";
            // 
            // labelSexoEmpleados
            // 
            labelSexoEmpleados.AutoSize = true;
            labelSexoEmpleados.Location = new Point(185, 214);
            labelSexoEmpleados.Name = "labelSexoEmpleados";
            labelSexoEmpleados.Size = new Size(32, 15);
            labelSexoEmpleados.TabIndex = 7;
            labelSexoEmpleados.Text = "Sexo";
            // 
            // labelFechaNacimientoEmpleados
            // 
            labelFechaNacimientoEmpleados.AutoSize = true;
            labelFechaNacimientoEmpleados.Location = new Point(535, 185);
            labelFechaNacimientoEmpleados.Name = "labelFechaNacimientoEmpleados";
            labelFechaNacimientoEmpleados.Size = new Size(119, 15);
            labelFechaNacimientoEmpleados.TabIndex = 8;
            labelFechaNacimientoEmpleados.Text = "Fecha de Nacimiento";
            // 
            // label1FechaIngresoEmpleados
            // 
            label1FechaIngresoEmpleados.AutoSize = true;
            label1FechaIngresoEmpleados.Location = new Point(555, 214);
            label1FechaIngresoEmpleados.Name = "label1FechaIngresoEmpleados";
            label1FechaIngresoEmpleados.Size = new Size(80, 15);
            label1FechaIngresoEmpleados.TabIndex = 9;
            label1FechaIngresoEmpleados.Text = "Fecha Ingreso";
            // 
            // labelHorarioEmpleados
            // 
            labelHorarioEmpleados.AutoSize = true;
            labelHorarioEmpleados.Location = new Point(997, 111);
            labelHorarioEmpleados.Name = "labelHorarioEmpleados";
            labelHorarioEmpleados.Size = new Size(47, 15);
            labelHorarioEmpleados.TabIndex = 10;
            labelHorarioEmpleados.Text = "Horario";
            // 
            // radioButtonBuscarEmpleados
            // 
            radioButtonBuscarEmpleados.AutoSize = true;
            radioButtonBuscarEmpleados.Location = new Point(20, 7);
            radioButtonBuscarEmpleados.Name = "radioButtonBuscarEmpleados";
            radioButtonBuscarEmpleados.Size = new Size(60, 19);
            radioButtonBuscarEmpleados.TabIndex = 11;
            radioButtonBuscarEmpleados.TabStop = true;
            radioButtonBuscarEmpleados.Text = "Buscar";
            radioButtonBuscarEmpleados.UseVisualStyleBackColor = true;
            // 
            // radioButtonActualizarEmpleados
            // 
            radioButtonActualizarEmpleados.AutoSize = true;
            radioButtonActualizarEmpleados.Location = new Point(185, 7);
            radioButtonActualizarEmpleados.Name = "radioButtonActualizarEmpleados";
            radioButtonActualizarEmpleados.Size = new Size(77, 19);
            radioButtonActualizarEmpleados.TabIndex = 12;
            radioButtonActualizarEmpleados.TabStop = true;
            radioButtonActualizarEmpleados.Text = "Actualizar";
            radioButtonActualizarEmpleados.UseVisualStyleBackColor = true;
            // 
            // radioButtonIngresarEmpleados
            // 
            radioButtonIngresarEmpleados.AutoSize = true;
            radioButtonIngresarEmpleados.Location = new Point(101, 7);
            radioButtonIngresarEmpleados.Name = "radioButtonIngresarEmpleados";
            radioButtonIngresarEmpleados.Size = new Size(67, 19);
            radioButtonIngresarEmpleados.TabIndex = 13;
            radioButtonIngresarEmpleados.TabStop = true;
            radioButtonIngresarEmpleados.Text = "Ingresar";
            radioButtonIngresarEmpleados.UseVisualStyleBackColor = true;
            // 
            // radioButtonEliminarEmpleados
            // 
            radioButtonEliminarEmpleados.AutoSize = true;
            radioButtonEliminarEmpleados.Location = new Point(279, 7);
            radioButtonEliminarEmpleados.Name = "radioButtonEliminarEmpleados";
            radioButtonEliminarEmpleados.Size = new Size(68, 19);
            radioButtonEliminarEmpleados.TabIndex = 14;
            radioButtonEliminarEmpleados.TabStop = true;
            radioButtonEliminarEmpleados.Text = "Eliminar";
            radioButtonEliminarEmpleados.UseVisualStyleBackColor = true;
            // 
            // dateTimePickerFechaNacimientoEmpleados
            // 
            dateTimePickerFechaNacimientoEmpleados.Location = new Point(667, 182);
            dateTimePickerFechaNacimientoEmpleados.Name = "dateTimePickerFechaNacimientoEmpleados";
            dateTimePickerFechaNacimientoEmpleados.Size = new Size(238, 23);
            dateTimePickerFechaNacimientoEmpleados.TabIndex = 17;
            // 
            // dateTimePickerFechaIngresoEmpleados
            // 
            dateTimePickerFechaIngresoEmpleados.Location = new Point(667, 214);
            dateTimePickerFechaIngresoEmpleados.Name = "dateTimePickerFechaIngresoEmpleados";
            dateTimePickerFechaIngresoEmpleados.Size = new Size(238, 23);
            dateTimePickerFechaIngresoEmpleados.TabIndex = 18;
            // 
            // dataGridViewEmpleados
            // 
            dataGridViewEmpleados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEmpleados.Location = new Point(120, 260);
            dataGridViewEmpleados.Name = "dataGridViewEmpleados";
            dataGridViewEmpleados.Size = new Size(865, 237);
            dataGridViewEmpleados.TabIndex = 19;
            // 
            // buttonAceptarEmpleados
            // 
            buttonAceptarEmpleados.Location = new Point(452, 527);
            buttonAceptarEmpleados.Name = "buttonAceptarEmpleados";
            buttonAceptarEmpleados.Size = new Size(70, 24);
            buttonAceptarEmpleados.TabIndex = 20;
            buttonAceptarEmpleados.Text = "Aceptar";
            buttonAceptarEmpleados.UseVisualStyleBackColor = true;
            buttonAceptarEmpleados.Click += buttonAceptarEmpleados_Click;
            // 
            // buttonCancelarEmpleados
            // 
            buttonCancelarEmpleados.Location = new Point(565, 527);
            buttonCancelarEmpleados.Name = "buttonCancelarEmpleados";
            buttonCancelarEmpleados.Size = new Size(70, 24);
            buttonCancelarEmpleados.TabIndex = 21;
            buttonCancelarEmpleados.Text = "Cancelar";
            buttonCancelarEmpleados.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonFace;
            label1.Font = new Font("Castellar", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(365, 50);
            label1.Name = "label1";
            label1.Size = new Size(349, 25);
            label1.TabIndex = 22;
            label1.Text = "Informacion Empleados";
            // 
            // textBoxCedulaEmpleados
            // 
            textBoxCedulaEmpleados.Location = new Point(3, 142);
            textBoxCedulaEmpleados.Name = "textBoxCedulaEmpleados";
            textBoxCedulaEmpleados.Size = new Size(120, 23);
            textBoxCedulaEmpleados.TabIndex = 23;
            // 
            // textBoxIDEmpleados
            // 
            textBoxIDEmpleados.Location = new Point(138, 142);
            textBoxIDEmpleados.Name = "textBoxIDEmpleados";
            textBoxIDEmpleados.Size = new Size(124, 23);
            textBoxIDEmpleados.TabIndex = 24;
            // 
            // textBoxNombre1Empleados
            // 
            textBoxNombre1Empleados.Location = new Point(279, 142);
            textBoxNombre1Empleados.Name = "textBoxNombre1Empleados";
            textBoxNombre1Empleados.Size = new Size(121, 23);
            textBoxNombre1Empleados.TabIndex = 25;
            // 
            // textBoxNombre2Empleados
            // 
            textBoxNombre2Empleados.Location = new Point(421, 142);
            textBoxNombre2Empleados.Name = "textBoxNombre2Empleados";
            textBoxNombre2Empleados.Size = new Size(118, 23);
            textBoxNombre2Empleados.TabIndex = 26;
            // 
            // textBoxAP1Empleados
            // 
            textBoxAP1Empleados.Location = new Point(555, 142);
            textBoxAP1Empleados.Name = "textBoxAP1Empleados";
            textBoxAP1Empleados.Size = new Size(115, 23);
            textBoxAP1Empleados.TabIndex = 27;
            // 
            // textBoxAP2Empleados
            // 
            textBoxAP2Empleados.Location = new Point(685, 142);
            textBoxAP2Empleados.Name = "textBoxAP2Empleados";
            textBoxAP2Empleados.Size = new Size(122, 23);
            textBoxAP2Empleados.TabIndex = 28;
            // 
            // textBoxEspecialidadEmpleados
            // 
            textBoxEspecialidadEmpleados.Location = new Point(837, 142);
            textBoxEspecialidadEmpleados.Name = "textBoxEspecialidadEmpleados";
            textBoxEspecialidadEmpleados.Size = new Size(118, 23);
            textBoxEspecialidadEmpleados.TabIndex = 29;
            // 
            // textBoxHorarioEmpleados
            // 
            textBoxHorarioEmpleados.Location = new Point(981, 142);
            textBoxHorarioEmpleados.Name = "textBoxHorarioEmpleados";
            textBoxHorarioEmpleados.Size = new Size(119, 23);
            textBoxHorarioEmpleados.TabIndex = 30;
            // 
            // textBoxSexoEmpleados
            // 
            textBoxSexoEmpleados.Location = new Point(235, 214);
            textBoxSexoEmpleados.Name = "textBoxSexoEmpleados";
            textBoxSexoEmpleados.Size = new Size(121, 23);
            textBoxSexoEmpleados.TabIndex = 31;
            // 
            // FrmEmpleados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(1112, 593);
            Controls.Add(textBoxSexoEmpleados);
            Controls.Add(textBoxHorarioEmpleados);
            Controls.Add(textBoxEspecialidadEmpleados);
            Controls.Add(textBoxAP2Empleados);
            Controls.Add(textBoxAP1Empleados);
            Controls.Add(textBoxNombre2Empleados);
            Controls.Add(textBoxNombre1Empleados);
            Controls.Add(textBoxIDEmpleados);
            Controls.Add(textBoxCedulaEmpleados);
            Controls.Add(label1);
            Controls.Add(buttonCancelarEmpleados);
            Controls.Add(buttonAceptarEmpleados);
            Controls.Add(dataGridViewEmpleados);
            Controls.Add(dateTimePickerFechaIngresoEmpleados);
            Controls.Add(dateTimePickerFechaNacimientoEmpleados);
            Controls.Add(radioButtonEliminarEmpleados);
            Controls.Add(radioButtonIngresarEmpleados);
            Controls.Add(radioButtonActualizarEmpleados);
            Controls.Add(radioButtonBuscarEmpleados);
            Controls.Add(labelHorarioEmpleados);
            Controls.Add(label1FechaIngresoEmpleados);
            Controls.Add(labelFechaNacimientoEmpleados);
            Controls.Add(labelSexoEmpleados);
            Controls.Add(labelAP2Empleados);
            Controls.Add(label6);
            Controls.Add(labelAP1Empleados);
            Controls.Add(labelNombre2Empleados);
            Controls.Add(labelNombre1Empleados);
            Controls.Add(labelID_Empleados);
            Controls.Add(labelCedulaEmpleados);
            Name = "FrmEmpleados";
            Text = "Sistema Gimnasio-Empleados";
            Load += FrmEmpleados_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewEmpleados).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelCedulaEmpleados;
        private Label labelID_Empleados;
        private Label labelNombre1Empleados;
        private Label labelNombre2Empleados;
        private Label labelAP1Empleados;
        private Label label6;
        private ImageList imageList1;
        private Label labelAP2Empleados;
        private Label labelSexoEmpleados;
        private Label labelFechaNacimientoEmpleados;
        private Label label1FechaIngresoEmpleados;
        private Label labelHorarioEmpleados;
        private RadioButton radioButtonBuscarEmpleados;
        private RadioButton radioButtonActualizarEmpleados;
        private RadioButton radioButtonIngresarEmpleados;
        private RadioButton radioButtonEliminarEmpleados;
        private DateTimePicker dateTimePickerFechaNacimientoEmpleados;
        private DateTimePicker dateTimePickerFechaIngresoEmpleados;
        private DataGridView dataGridViewEmpleados;
        private Button buttonAceptarEmpleados;
        private Button buttonCancelarEmpleados;
        private Label label1;
        private TextBox textBoxCedulaEmpleados;
        private TextBox textBoxIDEmpleados;
        private TextBox textBoxNombre1Empleados;
        private TextBox textBoxNombre2Empleados;
        private TextBox textBoxAP1Empleados;
        private TextBox textBoxAP2Empleados;
        private TextBox textBoxEspecialidadEmpleados;
        private TextBox textBoxHorarioEmpleados;
        private TextBox textBoxSexoEmpleados;
    }
}