﻿using CapaEntidad;
using CapaNegocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FrmClientes : Form
    {
        private EntidadCliente pro;
        private DataTable table;
        private ClienteHelper ProdH;

        public FrmClientes()
        {
            InitializeComponent();
        }


        #region ExisteCliente
        private bool ExisteUsuario()
        {
            bool Existe = false;
            pro = new EntidadCliente();
            pro.opc = 2;
            pro.Cedula_Cliente = this.textBoxCedulaCliente.Text;
            ProdH = new ClienteHelper(pro);
            table = new DataTable();

            table = ProdH.ValidaCodigo();

            if (table.Rows.Count > 0)
            {
                Existe = true; 
            }
            return Existe;
        }

        #endregion

        #region Metodo LimpiarCampos()

        private void LimpiarCampos()
        {
            textBoxCedulaCliente.Text = "";
            textBoxNombre1Cliente.Text = "";
            textBoxNombre2Cliente.Text = "";
            textBoxAP1Cliente.Text = "";
            textBoxAP2Cliente.Text = "";
            textBoxSexoCliente.Text = "";
            textBoxAP2Cliente.Text = "";
            textBoxEstadoCliente.Text = "";
            dateTimePickerFechaNacimiento.Value = new DateTime(2000, 1, 1);
            dateTimePickerFechaIngreso.Value = new DateTime(2000, 1, 1);
        }

        #endregion


        private void FrmClientes_Load(object sender, EventArgs e)
        {

        }
        #region GuardarCliente()
        private void GuardarCliente()
        {
            try
            {
                if (ExisteUsuario())
                {
                    MessageBox.Show("El numero de cedula ya esta registrado");
                    this.textBoxCedulaCliente.Clear();
                }
                else
                {
                    if (this.textBoxCedulaCliente.Text != "" && 
                        this.textBoxNombre1Cliente.Text != "" && 
                        this.textBoxAP1Cliente.Text != "" &&
                        this.textBoxAP2Cliente.Text != "")
                    {
                        this.pro = new EntidadCliente();
                        this.pro.opc = 3;
                        this.pro.Cedula_Cliente = this.textBoxCedulaCliente.Text;
                        this.pro.Nombre1 = this.textBoxNombre1Cliente.Text;
                        this.pro.Nombre2 = this.textBoxNombre2Cliente.Text;
                        this.pro.AP1 = this.textBoxAP1Cliente.Text;
                        this.pro.AP2 = this.textBoxAP2Cliente.Text;
                        this.pro.ID_Membresia = this.textBoxID_MembresiaCliente.Text.Trim();
                        this.pro.Sexo = this.textBoxSexoCliente.Text;
                        this.pro.Estado = this.textBoxEstadoCliente.Text;
                        DateTime FechaNacimiento = dateTimePickerFechaNacimiento.Value;
                        this.pro.FechaNacimiento = FechaNacimiento;
                        DateTime FechaIngreso = dateTimePickerFechaIngreso.Value;
                        this.pro.FechaIngreso = FechaIngreso;
                        ;

                        ProdH = new ClienteHelper(pro);
                        ProdH.GuardarClientes();
                        MessageBox.Show("Cliente Almacenado");
                        Listar();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el cliente: " + ex.Message);
            }
        }

        #endregion

        #region Metodo Listar Clientes()

        private async void Listar()
        {
            try
            {
                pro = new EntidadCliente();
                pro.opc = 1;

                ProdH = new ClienteHelper(pro);
                table = ProdH.Listar();

                if (table != null && table.Rows.Count > 0)
                {
                    dataGridViewClientes.DataSource = table;
                }
                else
                {
                    MessageBox.Show("La tabla esta vacia o no se inicializo correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region Metodo Actulizar

        private void ActualizarCliente()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxCedulaCliente.Text))
                {
                    MessageBox.Show("Ingrese la cedula que desea actualizar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBoxCedulaCliente.Text, out int id))
                {
                    MessageBox.Show("La cedula debe ser un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxCedulaCliente.Text) ||
                    string.IsNullOrWhiteSpace(textBoxNombre1Cliente.Text) ||
                    string.IsNullOrWhiteSpace(textBoxNombre2Cliente.Text) ||
                    string.IsNullOrWhiteSpace(textBoxAP1Cliente.Text) ||
                    string.IsNullOrWhiteSpace(textBoxAP2Cliente.Text) ||
                    string.IsNullOrWhiteSpace(textBoxSexoCliente.Text) ||
                    string.IsNullOrWhiteSpace(textBoxEstadoCliente.Text))
                {
                    MessageBox.Show("Complete todos los campos para actualizar.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                pro = new EntidadCliente();
                ProdH = new ClienteHelper(pro);

                pro.opc = 4;
                pro.Cedula_Cliente = textBoxCedulaCliente.Text.Trim();
                pro.Nombre1 = textBoxNombre1Cliente.Text.Trim();
                pro.Nombre2 = textBoxNombre2Cliente.Text.Trim();
                pro.AP1 = textBoxAP1Cliente.Text.Trim();
                pro.AP2 = textBoxAP2Cliente.Text.Trim();
                pro.Sexo = textBoxSexoCliente.Text.Trim();
                pro.Estado = textBoxEstadoCliente.Text.Trim();
                pro.FechaNacimiento = dateTimePickerFechaNacimiento.Value;
                pro.FechaIngreso = dateTimePickerFechaIngreso.Value;
                ProdH.ActualizarCliente();

                MessageBox.Show("Persona actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Listar();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Método Eliminar

        private void EliminarCliente()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxCedulaCliente.Text))
                {
                    MessageBox.Show("Ingrese la cédula del cliente que desea eliminar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar este cliente?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmacion == DialogResult.No)
                    return;

                pro = new EntidadCliente();
                ProdH = new ClienteHelper(pro);

                pro.opc = 5; 
                pro.Cedula_Cliente = textBoxCedulaCliente.Text.Trim();

                ProdH.EliminarCliente(); 

                MessageBox.Show("Cliente eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Listar();          
                LimpiarCampos();   
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion




        private void buttonAceptarClientes_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonBuscarClientes.Checked)
                {
                    Listar();
                }
                if (radioButtonIngresarClientes.Checked)
                {
                    GuardarCliente();
                }
                if (radioButtonActualizarClientes.Checked)
                {
                    ActualizarCliente();
                }
                if (radioButtonEliminarCliente.Checked)
                {
                    DialogResult result = MessageBox.Show("¿Desea Eliminar?", "Eliminar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        EliminarCliente();
                    }
                    else
                    {
                        //Limpiar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBoxAP1Cliente_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
