﻿namespace Presentacion
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsuario = new Label();
            labelPassword = new Label();
            textBoxUsuario = new TextBox();
            textBoxContraseña = new TextBox();
            buttonIniciarSesion = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // labelUsuario
            // 
            labelUsuario.AutoSize = true;
            labelUsuario.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelUsuario.Location = new Point(262, 171);
            labelUsuario.Name = "labelUsuario";
            labelUsuario.Size = new Size(64, 21);
            labelUsuario.TabIndex = 0;
            labelUsuario.Text = "Usuario";
            // 
            // labelPassword
            // 
            labelPassword.AutoSize = true;
            labelPassword.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelPassword.Location = new Point(262, 229);
            labelPassword.Name = "labelPassword";
            labelPassword.Size = new Size(76, 21);
            labelPassword.TabIndex = 1;
            labelPassword.Text = "Password";
            // 
            // textBoxUsuario
            // 
            textBoxUsuario.Location = new Point(344, 173);
            textBoxUsuario.Name = "textBoxUsuario";
            textBoxUsuario.Size = new Size(123, 23);
            textBoxUsuario.TabIndex = 2;
            // 
            // textBoxContraseña
            // 
            textBoxContraseña.Location = new Point(344, 231);
            textBoxContraseña.Name = "textBoxContraseña";
            textBoxContraseña.Size = new Size(123, 23);
            textBoxContraseña.TabIndex = 3;
            // 
            // buttonIniciarSesion
            // 
            buttonIniciarSesion.Location = new Point(313, 283);
            buttonIniciarSesion.Name = "buttonIniciarSesion";
            buttonIniciarSesion.Size = new Size(154, 28);
            buttonIniciarSesion.TabIndex = 4;
            buttonIniciarSesion.Text = "Iniciar Seccion";
            buttonIniciarSesion.UseVisualStyleBackColor = true;
            buttonIniciarSesion.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonFace;
            label1.Font = new Font("Castellar", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(247, 70);
            label1.Name = "label1";
            label1.Size = new Size(270, 25);
            label1.TabIndex = 5;
            label1.Text = "Ingreso al Sistema";
            // 
            // FrmRoles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(buttonIniciarSesion);
            Controls.Add(textBoxContraseña);
            Controls.Add(textBoxUsuario);
            Controls.Add(labelPassword);
            Controls.Add(labelUsuario);
            Name = "FrmRoles";
            Text = "Sistema Gimnasio-Roles";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelUsuario;
        private Label labelPassword;
        private TextBox textBoxUsuario;
        private TextBox textBoxContraseña;
        private Button buttonIniciarSesion;
        private Label label1;
    }
}