﻿namespace Presentacion
{
    partial class FrmClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelCedulaCliente = new Label();
            labelNombre1Cliente = new Label();
            labelNombre2Cliente = new Label();
            labelAP1Cliente = new Label();
            labelAP2Cliente = new Label();
            labelSexo = new Label();
            dateTimePickerFechaNacimiento = new DateTimePicker();
            dateTimePickerFechaIngreso = new DateTimePicker();
            labelFechaNacimiento = new Label();
            labelFechaIngresoC = new Label();
            labelTitulo = new Label();
            textBoxCedulaCliente = new TextBox();
            textBoxNombre1Cliente = new TextBox();
            textBoxNombre2Cliente = new TextBox();
            textBoxAP2Cliente = new TextBox();
            textBoxAP1Cliente = new TextBox();
            buttonAceptarClientes = new Button();
            buttonCancelarClientes = new Button();
            radioButtonBuscarClientes = new RadioButton();
            radioButtonActualizarClientes = new RadioButton();
            radioButtonIngresarClientes = new RadioButton();
            radioButtonEliminarCliente = new RadioButton();
            dataGridViewClientes = new DataGridView();
            labelID_MembresiaC = new Label();
            textBoxSexoCliente = new TextBox();
            textBoxID_MembresiaCliente = new TextBox();
            labelEstadoCliente = new Label();
            textBoxEstadoCliente = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewClientes).BeginInit();
            SuspendLayout();
            // 
            // labelCedulaCliente
            // 
            labelCedulaCliente.AutoSize = true;
            labelCedulaCliente.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelCedulaCliente.Location = new Point(96, 95);
            labelCedulaCliente.Name = "labelCedulaCliente";
            labelCedulaCliente.Size = new Size(44, 15);
            labelCedulaCliente.TabIndex = 0;
            labelCedulaCliente.Text = "Cedula";
            // 
            // labelNombre1Cliente
            // 
            labelNombre1Cliente.AutoSize = true;
            labelNombre1Cliente.Location = new Point(282, 95);
            labelNombre1Cliente.Name = "labelNombre1Cliente";
            labelNombre1Cliente.Size = new Size(89, 15);
            labelNombre1Cliente.TabIndex = 1;
            labelNombre1Cliente.Text = "Primer Nombre";
            // 
            // labelNombre2Cliente
            // 
            labelNombre2Cliente.AutoSize = true;
            labelNombre2Cliente.Location = new Point(465, 95);
            labelNombre2Cliente.Name = "labelNombre2Cliente";
            labelNombre2Cliente.Size = new Size(101, 15);
            labelNombre2Cliente.TabIndex = 2;
            labelNombre2Cliente.Text = "Segundo Nombre";
            // 
            // labelAP1Cliente
            // 
            labelAP1Cliente.AutoSize = true;
            labelAP1Cliente.Location = new Point(671, 95);
            labelAP1Cliente.Name = "labelAP1Cliente";
            labelAP1Cliente.Size = new Size(89, 15);
            labelAP1Cliente.TabIndex = 3;
            labelAP1Cliente.Text = "Primer Apellido";
            // 
            // labelAP2Cliente
            // 
            labelAP2Cliente.AutoSize = true;
            labelAP2Cliente.Location = new Point(891, 95);
            labelAP2Cliente.Name = "labelAP2Cliente";
            labelAP2Cliente.Size = new Size(101, 15);
            labelAP2Cliente.TabIndex = 4;
            labelAP2Cliente.Text = "Segundo Apellido";
            // 
            // labelSexo
            // 
            labelSexo.AutoSize = true;
            labelSexo.Location = new Point(209, 163);
            labelSexo.Name = "labelSexo";
            labelSexo.Size = new Size(32, 15);
            labelSexo.TabIndex = 5;
            labelSexo.Text = "Sexo";
            // 
            // dateTimePickerFechaNacimiento
            // 
            dateTimePickerFechaNacimiento.Location = new Point(656, 177);
            dateTimePickerFechaNacimiento.Name = "dateTimePickerFechaNacimiento";
            dateTimePickerFechaNacimiento.Size = new Size(231, 23);
            dateTimePickerFechaNacimiento.TabIndex = 6;
            // 
            // dateTimePickerFechaIngreso
            // 
            dateTimePickerFechaIngreso.Location = new Point(656, 214);
            dateTimePickerFechaIngreso.Name = "dateTimePickerFechaIngreso";
            dateTimePickerFechaIngreso.Size = new Size(231, 23);
            dateTimePickerFechaIngreso.TabIndex = 7;
            // 
            // labelFechaNacimiento
            // 
            labelFechaNacimiento.AutoSize = true;
            labelFechaNacimiento.Location = new Point(470, 183);
            labelFechaNacimiento.Name = "labelFechaNacimiento";
            labelFechaNacimiento.Size = new Size(119, 15);
            labelFechaNacimiento.TabIndex = 10;
            labelFechaNacimiento.Text = "Fecha de Nacimiento";
            // 
            // labelFechaIngresoC
            // 
            labelFechaIngresoC.AutoSize = true;
            labelFechaIngresoC.Location = new Point(470, 214);
            labelFechaIngresoC.Name = "labelFechaIngresoC";
            labelFechaIngresoC.Size = new Size(96, 15);
            labelFechaIngresoC.TabIndex = 11;
            labelFechaIngresoC.Text = "Fecha de Ingreso";
            // 
            // labelTitulo
            // 
            labelTitulo.AutoSize = true;
            labelTitulo.BackColor = SystemColors.ButtonFace;
            labelTitulo.Font = new Font("Castellar", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelTitulo.Location = new Point(437, 38);
            labelTitulo.Name = "labelTitulo";
            labelTitulo.Size = new Size(307, 25);
            labelTitulo.TabIndex = 12;
            labelTitulo.Text = "Informacion Cliente";
            // 
            // textBoxCedulaCliente
            // 
            textBoxCedulaCliente.Location = new Point(54, 128);
            textBoxCedulaCliente.Name = "textBoxCedulaCliente";
            textBoxCedulaCliente.Size = new Size(133, 23);
            textBoxCedulaCliente.TabIndex = 13;
            // 
            // textBoxNombre1Cliente
            // 
            textBoxNombre1Cliente.Location = new Point(247, 128);
            textBoxNombre1Cliente.Name = "textBoxNombre1Cliente";
            textBoxNombre1Cliente.Size = new Size(156, 23);
            textBoxNombre1Cliente.TabIndex = 14;
            // 
            // textBoxNombre2Cliente
            // 
            textBoxNombre2Cliente.Location = new Point(453, 128);
            textBoxNombre2Cliente.Name = "textBoxNombre2Cliente";
            textBoxNombre2Cliente.Size = new Size(136, 23);
            textBoxNombre2Cliente.TabIndex = 15;
            // 
            // textBoxAP2Cliente
            // 
            textBoxAP2Cliente.Location = new Point(868, 128);
            textBoxAP2Cliente.Name = "textBoxAP2Cliente";
            textBoxAP2Cliente.Size = new Size(152, 23);
            textBoxAP2Cliente.TabIndex = 16;
            // 
            // textBoxAP1Cliente
            // 
            textBoxAP1Cliente.Location = new Point(644, 128);
            textBoxAP1Cliente.Name = "textBoxAP1Cliente";
            textBoxAP1Cliente.Size = new Size(135, 23);
            textBoxAP1Cliente.TabIndex = 17;
            textBoxAP1Cliente.TextChanged += textBoxAP1Cliente_TextChanged;
            // 
            // buttonAceptarClientes
            // 
            buttonAceptarClientes.Location = new Point(453, 576);
            buttonAceptarClientes.Name = "buttonAceptarClientes";
            buttonAceptarClientes.Size = new Size(75, 23);
            buttonAceptarClientes.TabIndex = 18;
            buttonAceptarClientes.Text = "Aceptar";
            buttonAceptarClientes.UseVisualStyleBackColor = true;
            buttonAceptarClientes.Click += buttonAceptarClientes_Click;
            // 
            // buttonCancelarClientes
            // 
            buttonCancelarClientes.Location = new Point(644, 576);
            buttonCancelarClientes.Name = "buttonCancelarClientes";
            buttonCancelarClientes.Size = new Size(75, 23);
            buttonCancelarClientes.TabIndex = 19;
            buttonCancelarClientes.Text = "Cancelar";
            buttonCancelarClientes.UseVisualStyleBackColor = true;
            // 
            // radioButtonBuscarClientes
            // 
            radioButtonBuscarClientes.AutoSize = true;
            radioButtonBuscarClientes.Location = new Point(12, 12);
            radioButtonBuscarClientes.Name = "radioButtonBuscarClientes";
            radioButtonBuscarClientes.Size = new Size(60, 19);
            radioButtonBuscarClientes.TabIndex = 20;
            radioButtonBuscarClientes.TabStop = true;
            radioButtonBuscarClientes.Text = "Buscar";
            radioButtonBuscarClientes.UseVisualStyleBackColor = true;
            // 
            // radioButtonActualizarClientes
            // 
            radioButtonActualizarClientes.AutoSize = true;
            radioButtonActualizarClientes.Location = new Point(151, 12);
            radioButtonActualizarClientes.Name = "radioButtonActualizarClientes";
            radioButtonActualizarClientes.Size = new Size(77, 19);
            radioButtonActualizarClientes.TabIndex = 21;
            radioButtonActualizarClientes.TabStop = true;
            radioButtonActualizarClientes.Text = "Actualizar";
            radioButtonActualizarClientes.UseVisualStyleBackColor = true;
            // 
            // radioButtonIngresarClientes
            // 
            radioButtonIngresarClientes.AutoSize = true;
            radioButtonIngresarClientes.Location = new Point(78, 12);
            radioButtonIngresarClientes.Name = "radioButtonIngresarClientes";
            radioButtonIngresarClientes.Size = new Size(67, 19);
            radioButtonIngresarClientes.TabIndex = 22;
            radioButtonIngresarClientes.TabStop = true;
            radioButtonIngresarClientes.Text = "Ingresar";
            radioButtonIngresarClientes.UseVisualStyleBackColor = true;
            // 
            // radioButtonEliminarCliente
            // 
            radioButtonEliminarCliente.AutoSize = true;
            radioButtonEliminarCliente.Location = new Point(260, 12);
            radioButtonEliminarCliente.Name = "radioButtonEliminarCliente";
            radioButtonEliminarCliente.Size = new Size(68, 19);
            radioButtonEliminarCliente.TabIndex = 23;
            radioButtonEliminarCliente.TabStop = true;
            radioButtonEliminarCliente.Text = "Eliminar";
            radioButtonEliminarCliente.UseVisualStyleBackColor = true;
            // 
            // dataGridViewClientes
            // 
            dataGridViewClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewClientes.Location = new Point(54, 245);
            dataGridViewClientes.Name = "dataGridViewClientes";
            dataGridViewClientes.Size = new Size(1085, 288);
            dataGridViewClientes.TabIndex = 24;
            // 
            // labelID_MembresiaC
            // 
            labelID_MembresiaC.AutoSize = true;
            labelID_MembresiaC.Location = new Point(159, 192);
            labelID_MembresiaC.Name = "labelID_MembresiaC";
            labelID_MembresiaC.Size = new Size(82, 15);
            labelID_MembresiaC.TabIndex = 25;
            labelID_MembresiaC.Text = "ID_Membresia";
            // 
            // textBoxSexoCliente
            // 
            textBoxSexoCliente.Location = new Point(247, 160);
            textBoxSexoCliente.Name = "textBoxSexoCliente";
            textBoxSexoCliente.Size = new Size(156, 23);
            textBoxSexoCliente.TabIndex = 26;
            // 
            // textBoxID_MembresiaCliente
            // 
            textBoxID_MembresiaCliente.Location = new Point(247, 189);
            textBoxID_MembresiaCliente.Name = "textBoxID_MembresiaCliente";
            textBoxID_MembresiaCliente.Size = new Size(156, 23);
            textBoxID_MembresiaCliente.TabIndex = 27;
            // 
            // labelEstadoCliente
            // 
            labelEstadoCliente.AutoSize = true;
            labelEstadoCliente.Location = new Point(199, 214);
            labelEstadoCliente.Name = "labelEstadoCliente";
            labelEstadoCliente.Size = new Size(42, 15);
            labelEstadoCliente.TabIndex = 28;
            labelEstadoCliente.Text = "Estado";
            // 
            // textBoxEstadoCliente
            // 
            textBoxEstadoCliente.Location = new Point(247, 216);
            textBoxEstadoCliente.Name = "textBoxEstadoCliente";
            textBoxEstadoCliente.Size = new Size(156, 23);
            textBoxEstadoCliente.TabIndex = 29;
            // 
            // FrmClientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(1200, 633);
            Controls.Add(textBoxEstadoCliente);
            Controls.Add(labelEstadoCliente);
            Controls.Add(textBoxID_MembresiaCliente);
            Controls.Add(textBoxSexoCliente);
            Controls.Add(labelID_MembresiaC);
            Controls.Add(dataGridViewClientes);
            Controls.Add(radioButtonEliminarCliente);
            Controls.Add(radioButtonIngresarClientes);
            Controls.Add(radioButtonActualizarClientes);
            Controls.Add(radioButtonBuscarClientes);
            Controls.Add(buttonCancelarClientes);
            Controls.Add(buttonAceptarClientes);
            Controls.Add(textBoxAP1Cliente);
            Controls.Add(textBoxAP2Cliente);
            Controls.Add(textBoxNombre2Cliente);
            Controls.Add(textBoxNombre1Cliente);
            Controls.Add(textBoxCedulaCliente);
            Controls.Add(labelTitulo);
            Controls.Add(labelFechaIngresoC);
            Controls.Add(labelFechaNacimiento);
            Controls.Add(dateTimePickerFechaIngreso);
            Controls.Add(dateTimePickerFechaNacimiento);
            Controls.Add(labelSexo);
            Controls.Add(labelAP2Cliente);
            Controls.Add(labelAP1Cliente);
            Controls.Add(labelNombre2Cliente);
            Controls.Add(labelNombre1Cliente);
            Controls.Add(labelCedulaCliente);
            Name = "FrmClientes";
            Text = "Sistema Gimnasio-Clientes";
            Load += FrmClientes_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewClientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelCedulaCliente;
        private Label labelNombre1Cliente;
        private Label labelNombre2Cliente;
        private Label labelAP1Cliente;
        private Label labelAP2Cliente;
        private Label labelSexo;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label labelFechaNacimiento;
        private Label labelFechaIngresoC;
        private Label labelTitulo;
        private TextBox textBoxCedulaCliente;
        private TextBox textBoxNombre1Cliente;
        private TextBox textBoxNombre2Cliente;
        private TextBox textBoxAP2Cliente;
        private TextBox textBoxAP1Cliente;
        private Button buttonAceptarClientes;
        private Button buttonCancelarClientes;
        private DateTimePicker dateTimePickerFechaNacimiento;
        private DateTimePicker dateTimePickerFechaIngreso;
        private RadioButton radioButtonBuscarClientes;
        private RadioButton radioButtonActualizarClientes;
        private RadioButton radioButtonIngresarClientes;
        private RadioButton radioButtonEliminarCliente;
        private DataGridView dataGridViewClientes;
        private Label labelID_MembresiaC;
        private TextBox textBoxSexoCliente;
        private TextBox textBoxID_MembresiaCliente;
        private Label labelEstadoCliente;
        private TextBox textBoxEstadoCliente;
    }
}