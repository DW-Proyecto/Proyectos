﻿using CapaEntidad;
using CapaNegocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FrmEmpleados : Form
    {
        private EntidadEmpleados pro;
        private DataTable table;
        private EmpleadosHelper ProdH;
        public FrmEmpleados()
        {
            InitializeComponent();
        }

        #region Metodo LimpiarCampos()

        private void LimpiarCampos()
        {
            textBoxCedulaEmpleados.Text = "";
            textBoxIDEmpleados.Text = "";
            textBoxNombre1Empleados.Text = "";
            textBoxNombre2Empleados.Text = "";
            textBoxAP1Empleados.Text = "";
            textBoxAP2Empleados.Text = "";
            textBoxEspecialidadEmpleados.Text = "";
            textBoxHorarioEmpleados.Text = "";
            textBoxSexoEmpleados.Text = "";
            dateTimePickerFechaNacimientoEmpleados.Value = new DateTime(2000, 1, 1);
            dateTimePickerFechaIngresoEmpleados.Value = new DateTime(2000, 1, 1);
        }

        #endregion


        #region ExisteEmpleado
        private bool ExisteEmpleado()
        {
            bool Existe = false;
            pro = new EntidadEmpleados();
            pro.opc = 2;
            pro.ID_Empleado = this.textBoxIDEmpleados.Text;
            ProdH = new EmpleadosHelper(pro);
            table = new DataTable();

            table = ProdH.ValidaCodigoEmpleados();

            if (table.Rows.Count > 0)
            {
                Existe = true;
            }
            return Existe;
        }

        #endregion

        #region GuardarEmpleado()
        private void GuardarEmpleado()
        {
            try
            {
                if (ExisteEmpleado())
                {
                    MessageBox.Show("El de ID ya esta registrado");
                    this.textBoxIDEmpleados.Clear();
                }
                else
                {
                    if (this.textBoxCedulaEmpleados.Text != "" &&
                        this.textBoxIDEmpleados.Text != "" &&
                        this.textBoxNombre1Empleados.Text != "" &&
                        this.textBoxNombre2Empleados.Text != ""&&
                        this.textBoxAP1Empleados.Text != "" &&
                        this.textBoxAP2Empleados.Text != "" )

                    {
                        this.pro = new EntidadEmpleados();
                        this.pro.opc = 3;
                        this.pro.Cedula_Empleados = this.textBoxCedulaEmpleados.Text;
                        this.pro.ID_Empleado = this.textBoxIDEmpleados.Text;
                        this.pro.Nombre1 = this.textBoxNombre1Empleados.Text;
                        this.pro.Nombre2 = this.textBoxNombre2Empleados.Text;
                        this.pro.AP1 = this.textBoxAP1Empleados.Text;
                        this.pro.AP2 = this.textBoxAP2Empleados.Text;
                        this.pro.Especialidad = this.textBoxEspecialidadEmpleados.Text;
                        this.pro.Horario = this.textBoxHorarioEmpleados.Text;
                        this.pro.Sexo = this.textBoxSexoEmpleados.Text;
                        
                        DateTime FechaNacimiento = dateTimePickerFechaNacimientoEmpleados.Value;
                        this.pro.FechaNacimiento = FechaNacimiento;
                        DateTime FechaIngreso = dateTimePickerFechaIngresoEmpleados.Value;
                        this.pro.FechaIngreso = FechaIngreso;
                        ;

                        ProdH = new EmpleadosHelper(pro);
                        ProdH.GuardarEmpleados();
                        MessageBox.Show("Empleado Almacenado");
                        ListarEmpleados();
                        LimpiarCampos();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el empleado: " + ex.Message);
            }
        }

        #endregion

        #region Metodo Listar Empleados()

        private async void ListarEmpleados()
        {
            try
            {
                pro = new EntidadEmpleados();
                pro.opc = 1;

                ProdH = new EmpleadosHelper(pro);
                table = ProdH.ListarEmpleados();

                if (table != null && table.Rows.Count > 0)
                {
                    dataGridViewEmpleados.DataSource = table;
                }
                else
                {
                    MessageBox.Show("La tabla esta vacia o no se inicializo correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region Metodo Actulizar

        private void ActualizarEmpleados()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxIDEmpleados.Text))
                {
                    MessageBox.Show("Ingrese el ID del Empleado que desea actualizar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxIDEmpleados.Text))
                {
                    MessageBox.Show("El ID debe ser un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxIDEmpleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxCedulaEmpleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxIDEmpleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxNombre1Empleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxNombre2Empleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxAP1Empleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxAP2Empleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxEspecialidadEmpleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxHorarioEmpleados.Text) ||
                    string.IsNullOrWhiteSpace(textBoxSexoEmpleados.Text))

                {
                    MessageBox.Show("Complete todos los campos para actualizar.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                pro = new EntidadEmpleados
                    ();
                ProdH = new EmpleadosHelper(pro);

                pro.opc = 4;
                pro.ID_Empleado = textBoxIDEmpleados.Text.Trim();
                pro.Cedula_Empleados = textBoxCedulaEmpleados.Text.Trim();
                pro.Nombre1 = textBoxNombre1Empleados.Text.Trim();
                pro.Nombre2 = textBoxNombre2Empleados.Text.Trim();
                pro.AP1 = textBoxAP1Empleados.Text.Trim();
                pro.AP2 = textBoxAP2Empleados.Text.Trim();
                pro.Especialidad = textBoxEspecialidadEmpleados.Text.Trim();
                pro.Horario = textBoxHorarioEmpleados.Text.Trim();
                pro.FechaNacimiento = dateTimePickerFechaNacimientoEmpleados.Value;
                pro.FechaIngreso = dateTimePickerFechaIngresoEmpleados.Value;
                ProdH.ActualizarEmpleados();

                MessageBox.Show("Persona actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarEmpleados();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Método Eliminar

        private void EliminarEmpleados()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxIDEmpleados.Text))
                {
                    MessageBox.Show("Ingrese el ID del empleado que desea eliminar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar este cliente?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmacion == DialogResult.No)
                    return;

                pro = new EntidadEmpleados();
                ProdH = new EmpleadosHelper(pro);

                pro.opc = 5;
                pro.ID_Empleado = textBoxIDEmpleados.Text.Trim();

                ProdH.EliminarEmpleaados();

                MessageBox.Show("Empleado eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarEmpleados();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion




        private void buttonAceptarEmpleados_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (radioButtonBuscarEmpleados.Checked)
                {
                    ListarEmpleados();
                }
                if (radioButtonIngresarEmpleados.Checked)
                {
                    GuardarEmpleado();
                }
                if (radioButtonActualizarEmpleados.Checked)
                {
                    ActualizarEmpleados();
                }
                if (radioButtonEliminarEmpleados.Checked)
                {
                    DialogResult result = MessageBox.Show("¿Desea Eliminar?", "Eliminar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        EliminarEmpleados();
                    }
                    else
                    {
                        //Limpiar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FrmEmpleados_Load(object sender, EventArgs e)
        {

        }

    
    }
}
