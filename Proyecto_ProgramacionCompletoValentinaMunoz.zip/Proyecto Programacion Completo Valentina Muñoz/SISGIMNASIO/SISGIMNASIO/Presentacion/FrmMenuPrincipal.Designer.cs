﻿namespace Presentacion
{
    partial class menuStripPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            menuClientesToolStripMenuItem = new ToolStripMenuItem();
            empleadosToolStripMenuItem = new ToolStripMenuItem();
            membresiasToolStripMenuItem = new ToolStripMenuItem();
            facturaToolStripMenuItem = new ToolStripMenuItem();
            rutinasToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuClientesToolStripMenuItem, empleadosToolStripMenuItem, membresiasToolStripMenuItem, facturaToolStripMenuItem, rutinasToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(894, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuClientesToolStripMenuItem
            // 
            menuClientesToolStripMenuItem.Name = "menuClientesToolStripMenuItem";
            menuClientesToolStripMenuItem.Size = new Size(64, 20);
            menuClientesToolStripMenuItem.Text = " Clientes";
            menuClientesToolStripMenuItem.Click += menuClientesToolStripMenuItem_Click;
            // 
            // empleadosToolStripMenuItem
            // 
            empleadosToolStripMenuItem.Name = "empleadosToolStripMenuItem";
            empleadosToolStripMenuItem.Size = new Size(77, 20);
            empleadosToolStripMenuItem.Text = "Empleados";
            empleadosToolStripMenuItem.Click += empleadosToolStripMenuItem_Click;
            // 
            // membresiasToolStripMenuItem
            // 
            membresiasToolStripMenuItem.Name = "membresiasToolStripMenuItem";
            membresiasToolStripMenuItem.Size = new Size(83, 20);
            membresiasToolStripMenuItem.Text = "Membresias";
            membresiasToolStripMenuItem.Click += membresiasToolStripMenuItem_Click;
            // 
            // facturaToolStripMenuItem
            // 
            facturaToolStripMenuItem.Name = "facturaToolStripMenuItem";
            facturaToolStripMenuItem.Size = new Size(58, 20);
            facturaToolStripMenuItem.Text = "Factura";
            facturaToolStripMenuItem.Click += facturaToolStripMenuItem_Click;
            // 
            // rutinasToolStripMenuItem
            // 
            rutinasToolStripMenuItem.Name = "rutinasToolStripMenuItem";
            rutinasToolStripMenuItem.Size = new Size(58, 20);
            rutinasToolStripMenuItem.Text = "Rutinas";
            rutinasToolStripMenuItem.Click += rutinasToolStripMenuItem_Click;
            // 
            // menuStripPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.IndianRed;
            ClientSize = new Size(894, 432);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "menuStripPrincipal";
            Text = "Menu Principal";
            Load += menuStripPrincipal_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuClientesToolStripMenuItem;
        private ToolStripMenuItem empleadosToolStripMenuItem;
        private ToolStripMenuItem membresiasToolStripMenuItem;
        private ToolStripMenuItem facturaToolStripMenuItem;
        private ToolStripMenuItem rutinasToolStripMenuItem;
    }
}
