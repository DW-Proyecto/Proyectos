﻿using CapaEntidad;
using CapaNegocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FrmMembresias : Form
    {
        private EntidadMembresia pro;
        private DataTable table;
        private MembresiaHelper ProdH;



        public FrmMembresias()
        {
            InitializeComponent();
        }

        #region Metodo LimpiarCampos()


        private void LimpiarCampos()
        {
            textBoxIDMembresia.Clear();
            textBoxDuracionMembresia.Clear();
            textBoxCostoMembresia.Clear();
            textBoxBeneficioMembresia.Clear();

            radioButtonMembresiaBasica.Checked = false;
            radioButtonMmebresiaPremium.Checked = false;
            radioButtonMembresiaVIP.Checked = false;
        }


        #endregion
        #region Existe Membresia
        private bool ExisteMembresia()
        {
            bool Existe = false;
            pro = new EntidadMembresia();
            pro.opc = 2;
            pro.ID_Membresia = this.textBoxIDMembresia.Text;
            ProdH = new MembresiaHelper(pro);
            table = new DataTable();

            table = ProdH.ValidaCodigoMembresia();

            if (table.Rows.Count > 0)
            {
                Existe = true;
            }
            return Existe;
        }

        #endregion

        #region Guardar Membresia
        private void GuardarMembresia()
        {
            try
            {
                if (ExisteMembresia())
                {
                    MessageBox.Show("El número de membresía ya está registrado.");
                    this.textBoxIDMembresia.Clear();

                }

                if (this.textBoxIDMembresia.Text != "" &&
                    this.textBoxDuracionMembresia.Text != "" &&
                    this.textBoxCostoMembresia.Text != "" &&
                    this.textBoxCostoMembresia.Text != "")
                {
                    if (!radioButtonMembresiaBasica.Checked &&
                        !radioButtonMmebresiaPremium.Checked &&
                        !radioButtonMembresiaVIP.Checked)
                    {
                        MessageBox.Show("Seleccione un tipo de membresía.");
                        return;
                    }


                    if (!int.TryParse(this.textBoxDuracionMembresia.Text, out int duracion))
                    {
                        MessageBox.Show("Duración inválida.");
                        return;
                    }
                    if (!decimal.TryParse(this.textBoxCostoMembresia.Text, out decimal costo))
                    {
                        MessageBox.Show("Costo inválido.");
                        return;
                    }

                    this.pro = new EntidadMembresia();
                    this.pro.opc = 3;
                    this.pro.ID_Membresia = this.textBoxIDMembresia.Text;
                    this.pro.DuracionMeses = int.Parse(this.textBoxDuracionMembresia.Text);
                    this.pro.Costo = decimal.Parse(this.textBoxCostoMembresia.Text);
                    this.pro.Beneficios = this.textBoxBeneficioMembresia.Text;

                    if (radioButtonMembresiaBasica.Checked)
                        this.pro.Tipo = "Basica";
                    else if (radioButtonMmebresiaPremium.Checked)
                        this.pro.Tipo = "Premium";
                    else if (radioButtonMembresiaVIP.Checked)
                        this.pro.Tipo = "VIP";

                    ProdH = new MembresiaHelper(pro);
                    ProdH.GuardarMembresia();

                    MessageBox.Show("Membresía almacenada.");
                    ListarMembresia();
                }
                else
                {
                    MessageBox.Show("Todos los campos son obligatorios.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la membresía: " + ex.Message);
            }
        }
        #endregion

        #region Metodo Listar Membresia()

        private async void ListarMembresia()
        {
            try
            {
                pro = new EntidadMembresia();
                pro.opc = 1;

                ProdH = new MembresiaHelper(pro);
                table = ProdH.ListarMembresia();

                if (table != null && table.Rows.Count > 0)
                {
                    dataGridViewMembresias.DataSource = table;
                }
                else
                {
                    MessageBox.Show("La tabla esta vacia o no se inicializo correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region
        private void ActualizarMembresia()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxIDMembresia.Text))
                {
                    MessageBox.Show("Ingrese el ID de la Membresía que desea actualizar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!radioButtonMembresiaBasica.Checked &&
                    !radioButtonMmebresiaPremium.Checked &&
                    !radioButtonMembresiaVIP.Checked)
                {
                    MessageBox.Show("Seleccione un tipo de membresía.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxDuracionMembresia.Text) ||
                    string.IsNullOrWhiteSpace(textBoxCostoMembresia.Text) ||
                    string.IsNullOrWhiteSpace(textBoxBeneficioMembresia.Text))
                {
                    MessageBox.Show("Complete todos los campos para actualizar.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                pro = new EntidadMembresia();
                pro.opc = 4;
                pro.ID_Membresia = textBoxIDMembresia.Text.Trim();
                pro.DuracionMeses = int.Parse(textBoxDuracionMembresia.Text);
                pro.Costo = decimal.Parse(textBoxCostoMembresia.Text);
                pro.Beneficios = textBoxBeneficioMembresia.Text.Trim();

                if (radioButtonMembresiaBasica.Checked)
                    pro.Tipo = "Basica";
                else if (radioButtonMmebresiaPremium.Checked)
                    pro.Tipo = "Premium";
                else if (radioButtonMembresiaVIP.Checked)
                    pro.Tipo = "VIP";

                ProdH = new MembresiaHelper(pro);
                ProdH.ActualizarMembresia(); // Asegúrate de tener este método

                MessageBox.Show("Membresía actualizada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarMembresia();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion 

        #region Método Eliminar

        private void EliminarMembresia()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxIDMembresia.Text))
                {
                    MessageBox.Show("Ingrese el ID del la Membresia que desea eliminar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar este cliente?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmacion == DialogResult.No)
                    return;

                pro = new EntidadMembresia();
                ProdH = new MembresiaHelper(pro);

                pro.opc = 5;
                pro.ID_Membresia = textBoxIDMembresia.Text.Trim();

                ProdH.EliminarMembresia();

                MessageBox.Show("Empleado eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarMembresia();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion


        private void FrmMembresias_Load(object sender, EventArgs e)
        {

        }

        private void buttonAceptarMembresia_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonBusacrMembresia.Checked)
                {
                    ListarMembresia();
                }
                if (radioButtonIngresarMembresia.Checked)
                {
                    GuardarMembresia();
                }
                if (radioButtonActualizarMmebresia.Checked)
                {
                    ActualizarMembresia();
                }
                if (radioButtonEliminarMembresia.Checked)
                {
                    DialogResult result = MessageBox.Show("¿Desea Eliminar?", "Eliminar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        EliminarMembresia();
                    }
                    else
                    {
                        //Limpiar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void groupBoxTipoMembresia_Enter(object sender, EventArgs e)
        {

        }

        private void groupBoxSeleccionMembresia_Enter(object sender, EventArgs e)
        {

        }

        private void radioButtonActualizarMmebresia_CheckedChanged(object sender, EventArgs e)
        {

        }
    }

}
