﻿namespace Presentacion
{
    partial class FrmFacturas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioButtonBuscarFacturas = new RadioButton();
            radioButtonActualizarFacturas = new RadioButton();
            radioButtonIngresarFacturas = new RadioButton();
            radioButtonEliminarFacturas = new RadioButton();
            labelCedula_CFactura = new Label();
            labelFechaEmisionFactura = new Label();
            labelMontoTotalFactura = new Label();
            labelEstadoFactura = new Label();
            dateTimePickerFechaEmisionFactura = new DateTimePicker();
            labelDetalleFactura = new Label();
            labelFacturacion = new Label();
            textBoxCedula_ClienteFactura = new TextBox();
            textBoxDetalleFactura = new TextBox();
            textBoxMontoTotalFactura = new TextBox();
            textBoxEstadoFactura = new TextBox();
            dataGridViewFacturacion = new DataGridView();
            buttonAceptarFacturas = new Button();
            buttonCancelarFacturas = new Button();
            labelMetodoPago = new Label();
            textBoxMetododepago = new TextBox();
            labelID_MembresiaFactura = new Label();
            textBoxIDMembresiaFactura = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridViewFacturacion).BeginInit();
            SuspendLayout();
            // 
            // radioButtonBuscarFacturas
            // 
            radioButtonBuscarFacturas.AutoSize = true;
            radioButtonBuscarFacturas.Location = new Point(12, 12);
            radioButtonBuscarFacturas.Name = "radioButtonBuscarFacturas";
            radioButtonBuscarFacturas.Size = new Size(60, 19);
            radioButtonBuscarFacturas.TabIndex = 0;
            radioButtonBuscarFacturas.TabStop = true;
            radioButtonBuscarFacturas.Text = "Buscar";
            radioButtonBuscarFacturas.UseVisualStyleBackColor = true;
            // 
            // radioButtonActualizarFacturas
            // 
            radioButtonActualizarFacturas.AutoSize = true;
            radioButtonActualizarFacturas.Location = new Point(151, 12);
            radioButtonActualizarFacturas.Name = "radioButtonActualizarFacturas";
            radioButtonActualizarFacturas.Size = new Size(77, 19);
            radioButtonActualizarFacturas.TabIndex = 1;
            radioButtonActualizarFacturas.TabStop = true;
            radioButtonActualizarFacturas.Text = "Actualizar";
            radioButtonActualizarFacturas.UseVisualStyleBackColor = true;
            // 
            // radioButtonIngresarFacturas
            // 
            radioButtonIngresarFacturas.AutoSize = true;
            radioButtonIngresarFacturas.Location = new Point(78, 12);
            radioButtonIngresarFacturas.Name = "radioButtonIngresarFacturas";
            radioButtonIngresarFacturas.Size = new Size(67, 19);
            radioButtonIngresarFacturas.TabIndex = 2;
            radioButtonIngresarFacturas.TabStop = true;
            radioButtonIngresarFacturas.Text = "Ingresar";
            radioButtonIngresarFacturas.UseVisualStyleBackColor = true;
            // 
            // radioButtonEliminarFacturas
            // 
            radioButtonEliminarFacturas.AutoSize = true;
            radioButtonEliminarFacturas.Location = new Point(237, 12);
            radioButtonEliminarFacturas.Name = "radioButtonEliminarFacturas";
            radioButtonEliminarFacturas.Size = new Size(68, 19);
            radioButtonEliminarFacturas.TabIndex = 3;
            radioButtonEliminarFacturas.TabStop = true;
            radioButtonEliminarFacturas.Text = "Eliminar";
            radioButtonEliminarFacturas.UseVisualStyleBackColor = true;
            // 
            // labelCedula_CFactura
            // 
            labelCedula_CFactura.AutoSize = true;
            labelCedula_CFactura.Location = new Point(321, 94);
            labelCedula_CFactura.Name = "labelCedula_CFactura";
            labelCedula_CFactura.Size = new Size(84, 15);
            labelCedula_CFactura.TabIndex = 4;
            labelCedula_CFactura.Text = "Cedula Cliente";
            // 
            // labelFechaEmisionFactura
            // 
            labelFechaEmisionFactura.AutoSize = true;
            labelFechaEmisionFactura.Location = new Point(321, 163);
            labelFechaEmisionFactura.Name = "labelFechaEmisionFactura";
            labelFechaEmisionFactura.Size = new Size(102, 15);
            labelFechaEmisionFactura.TabIndex = 5;
            labelFechaEmisionFactura.Text = "Fecha de Emision ";
            // 
            // labelMontoTotalFactura
            // 
            labelMontoTotalFactura.AutoSize = true;
            labelMontoTotalFactura.Location = new Point(321, 233);
            labelMontoTotalFactura.Name = "labelMontoTotalFactura";
            labelMontoTotalFactura.Size = new Size(71, 15);
            labelMontoTotalFactura.TabIndex = 6;
            labelMontoTotalFactura.Text = "Monto Total";
            // 
            // labelEstadoFactura
            // 
            labelEstadoFactura.AutoSize = true;
            labelEstadoFactura.Location = new Point(321, 318);
            labelEstadoFactura.Name = "labelEstadoFactura";
            labelEstadoFactura.Size = new Size(100, 15);
            labelEstadoFactura.TabIndex = 7;
            labelEstadoFactura.Text = "Estado de Factura";
            // 
            // dateTimePickerFechaEmisionFactura
            // 
            dateTimePickerFechaEmisionFactura.Location = new Point(439, 157);
            dateTimePickerFechaEmisionFactura.Name = "dateTimePickerFechaEmisionFactura";
            dateTimePickerFechaEmisionFactura.Size = new Size(246, 23);
            dateTimePickerFechaEmisionFactura.TabIndex = 8;
            // 
            // labelDetalleFactura
            // 
            labelDetalleFactura.AutoSize = true;
            labelDetalleFactura.Location = new Point(321, 196);
            labelDetalleFactura.Name = "labelDetalleFactura";
            labelDetalleFactura.Size = new Size(101, 15);
            labelDetalleFactura.TabIndex = 9;
            labelDetalleFactura.Text = "Detalle de Factura";
            // 
            // labelFacturacion
            // 
            labelFacturacion.AutoSize = true;
            labelFacturacion.BackColor = SystemColors.ButtonFace;
            labelFacturacion.Font = new Font("Castellar", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelFacturacion.Location = new Point(490, 55);
            labelFacturacion.Name = "labelFacturacion";
            labelFacturacion.Size = new Size(195, 25);
            labelFacturacion.TabIndex = 10;
            labelFacturacion.Text = "Facturacion";
            // 
            // textBoxCedula_ClienteFactura
            // 
            textBoxCedula_ClienteFactura.Location = new Point(445, 94);
            textBoxCedula_ClienteFactura.Name = "textBoxCedula_ClienteFactura";
            textBoxCedula_ClienteFactura.Size = new Size(240, 23);
            textBoxCedula_ClienteFactura.TabIndex = 11;
            // 
            // textBoxDetalleFactura
            // 
            textBoxDetalleFactura.Location = new Point(439, 196);
            textBoxDetalleFactura.Name = "textBoxDetalleFactura";
            textBoxDetalleFactura.Size = new Size(246, 23);
            textBoxDetalleFactura.TabIndex = 12;
            // 
            // textBoxMontoTotalFactura
            // 
            textBoxMontoTotalFactura.Location = new Point(439, 233);
            textBoxMontoTotalFactura.Name = "textBoxMontoTotalFactura";
            textBoxMontoTotalFactura.Size = new Size(246, 23);
            textBoxMontoTotalFactura.TabIndex = 13;
            // 
            // textBoxEstadoFactura
            // 
            textBoxEstadoFactura.Location = new Point(439, 318);
            textBoxEstadoFactura.Name = "textBoxEstadoFactura";
            textBoxEstadoFactura.Size = new Size(246, 23);
            textBoxEstadoFactura.TabIndex = 14;
            textBoxEstadoFactura.TextChanged += textBoxEstadoFactura_TextChanged;
            // 
            // dataGridViewFacturacion
            // 
            dataGridViewFacturacion.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewFacturacion.Location = new Point(94, 376);
            dataGridViewFacturacion.Name = "dataGridViewFacturacion";
            dataGridViewFacturacion.Size = new Size(1004, 235);
            dataGridViewFacturacion.TabIndex = 15;
            // 
            // buttonAceptarFacturas
            // 
            buttonAceptarFacturas.Location = new Point(464, 347);
            buttonAceptarFacturas.Name = "buttonAceptarFacturas";
            buttonAceptarFacturas.Size = new Size(75, 23);
            buttonAceptarFacturas.TabIndex = 16;
            buttonAceptarFacturas.Text = "Aceptar";
            buttonAceptarFacturas.UseVisualStyleBackColor = true;
            buttonAceptarFacturas.Click += button1_Click;
            // 
            // buttonCancelarFacturas
            // 
            buttonCancelarFacturas.Location = new Point(580, 347);
            buttonCancelarFacturas.Name = "buttonCancelarFacturas";
            buttonCancelarFacturas.Size = new Size(75, 23);
            buttonCancelarFacturas.TabIndex = 17;
            buttonCancelarFacturas.Text = "Cancelar";
            buttonCancelarFacturas.UseVisualStyleBackColor = true;
            // 
            // labelMetodoPago
            // 
            labelMetodoPago.AutoSize = true;
            labelMetodoPago.Location = new Point(321, 278);
            labelMetodoPago.Name = "labelMetodoPago";
            labelMetodoPago.Size = new Size(95, 15);
            labelMetodoPago.TabIndex = 18;
            labelMetodoPago.Text = "Metodo de pago";
            // 
            // textBoxMetododepago
            // 
            textBoxMetododepago.Location = new Point(439, 275);
            textBoxMetododepago.Name = "textBoxMetododepago";
            textBoxMetododepago.Size = new Size(246, 23);
            textBoxMetododepago.TabIndex = 19;
            // 
            // labelID_MembresiaFactura
            // 
            labelID_MembresiaFactura.AutoSize = true;
            labelID_MembresiaFactura.Location = new Point(321, 130);
            labelID_MembresiaFactura.Name = "labelID_MembresiaFactura";
            labelID_MembresiaFactura.Size = new Size(82, 15);
            labelID_MembresiaFactura.TabIndex = 20;
            labelID_MembresiaFactura.Text = "ID_Membresia";
            // 
            // textBoxIDMembresiaFactura
            // 
            textBoxIDMembresiaFactura.Location = new Point(445, 123);
            textBoxIDMembresiaFactura.Name = "textBoxIDMembresiaFactura";
            textBoxIDMembresiaFactura.Size = new Size(240, 23);
            textBoxIDMembresiaFactura.TabIndex = 21;
            // 
            // FrmFacturas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(1153, 647);
            Controls.Add(textBoxIDMembresiaFactura);
            Controls.Add(labelID_MembresiaFactura);
            Controls.Add(textBoxMetododepago);
            Controls.Add(labelMetodoPago);
            Controls.Add(buttonCancelarFacturas);
            Controls.Add(buttonAceptarFacturas);
            Controls.Add(dataGridViewFacturacion);
            Controls.Add(textBoxEstadoFactura);
            Controls.Add(textBoxMontoTotalFactura);
            Controls.Add(textBoxDetalleFactura);
            Controls.Add(textBoxCedula_ClienteFactura);
            Controls.Add(labelFacturacion);
            Controls.Add(labelDetalleFactura);
            Controls.Add(dateTimePickerFechaEmisionFactura);
            Controls.Add(labelEstadoFactura);
            Controls.Add(labelMontoTotalFactura);
            Controls.Add(labelFechaEmisionFactura);
            Controls.Add(labelCedula_CFactura);
            Controls.Add(radioButtonEliminarFacturas);
            Controls.Add(radioButtonIngresarFacturas);
            Controls.Add(radioButtonActualizarFacturas);
            Controls.Add(radioButtonBuscarFacturas);
            Name = "FrmFacturas";
            Text = "Sistema Gimnasio-Facturas";
            Load += FrmFacturas_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewFacturacion).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButtonBuscarFacturas;
        private RadioButton radioButtonActualizarFacturas;
        private RadioButton radioButtonIngresarFacturas;
        private RadioButton radioButtonEliminarFacturas;
        private Label labelCedula_CFactura;
        private Label labelFechaEmisionFactura;
        private Label labelMontoTotalFactura;
        private Label labelEstadoFactura;
        private DateTimePicker dateTimePickerFechaEmisionFactura;
        private Label labelDetalleFactura;
        private Label labelFacturacion;
        private TextBox textBoxCedula_ClienteFactura;
        private TextBox textBoxDetalleFactura;
        private TextBox textBoxMontoTotalFactura;
        private TextBox textBoxEstadoFactura;
        private DataGridView dataGridViewFacturacion;
        private Button buttonAceptarFacturas;
        private Button buttonCancelarFacturas;
        private Label labelMetodoPago;
        private TextBox textBoxMetododepago;
        private Label labelID_MembresiaFactura;
        private TextBox textBoxIDMembresiaFactura;
    }
}