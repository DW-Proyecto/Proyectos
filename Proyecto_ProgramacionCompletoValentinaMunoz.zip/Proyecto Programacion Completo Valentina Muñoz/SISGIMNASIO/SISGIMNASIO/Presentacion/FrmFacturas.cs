﻿using CapaEntidad;
using CapaNegocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FrmFacturas : Form
    {

        private EntidadFactura pro;
        private DataTable table;
        private FacturaHelper ProdH;
        public FrmFacturas()
        {
            InitializeComponent();
        }
        #region
        private void LimpiarCampos()
        {
            textBoxCedula_ClienteFactura.Text = "";
            textBoxIDMembresiaFactura.Text = "";
            textBoxDetalleFactura.Text = "";
            textBoxMontoTotalFactura.Text = "";
            textBoxMetododepago.Text = "";
            textBoxEstadoFactura.Text = "";
            dateTimePickerFechaEmisionFactura.Value = new DateTime(2000, 1, 1);
        }

        #endregion
        #region
        private void ActualizarFactura()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxCedula_ClienteFactura.Text))
                {
                    MessageBox.Show("Ingrese la Cedula de la Factura que desea actualizar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxCedula_ClienteFactura.Text))
                {
                    MessageBox.Show("La Cedula debe ser un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxCedula_ClienteFactura.Text) ||
                    string.IsNullOrWhiteSpace(textBoxIDMembresiaFactura.Text) ||
                    string.IsNullOrWhiteSpace(textBoxDetalleFactura.Text) ||
                    string.IsNullOrWhiteSpace(textBoxMontoTotalFactura.Text) ||
                    string.IsNullOrWhiteSpace(textBoxMetododepago.Text) ||
                    string.IsNullOrWhiteSpace(textBoxEstadoFactura.Text))

                {
                    MessageBox.Show("Complete todos los campos para actualizar.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                pro = new EntidadFactura();
                ProdH = new FacturaHelper(pro);

                pro.opc = 4;
                pro.Cedula_Cliente = textBoxCedula_ClienteFactura.Text.Trim();
                pro.ID_Membresia = textBoxIDMembresiaFactura.Text.Trim();
                pro.MetodoPago = textBoxMetododepago.Text.Trim();
                pro.MontoTotal = decimal.Parse(textBoxMontoTotalFactura.Text);
                pro.Detalle = textBoxDetalleFactura.Text.Trim();
                pro.Estado = textBoxEstadoFactura.Text.Trim();
                pro.FechaEmision = dateTimePickerFechaEmisionFactura.Value;

                ProdH.ActualizarFactura();

                MessageBox.Show("Factura actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarFacturas();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Método Eliminar

        private void EliminarFactura()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxCedula_ClienteFactura.Text))
                {
                    MessageBox.Show("Ingrese el Numero Cedula del Cliente que desea eliminar la Factura.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar esta Factura?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmacion == DialogResult.No)
                    return;

                pro = new EntidadFactura();
                ProdH = new FacturaHelper(pro);

                pro.opc = 5;
                pro.Cedula_Cliente = textBoxCedula_ClienteFactura.Text.Trim();

                ProdH.EliminarFactura();

                MessageBox.Show("Factura eliminada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarFacturas();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el cliente: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion



        #region Existe Factura
        private bool ExisteFactura()
        {
            bool Existe = false;
            pro = new EntidadFactura();
            pro.opc = 2;
            pro.Cedula_Cliente = this.textBoxCedula_ClienteFactura.Text;
            ProdH = new FacturaHelper(pro);
            table = new DataTable();

            table = ProdH.ValidaCodigoFactura();

            if (table.Rows.Count > 0)
            {
                Existe = true;
            }
            return Existe;

        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonBuscarFacturas.Checked)
                {
                    ListarFacturas();
                }
                if (radioButtonIngresarFacturas.Checked)
                {
                    GuardarFactura();
                }
                if (radioButtonActualizarFacturas.Checked)
                {
                    ActualizarFactura();
                }
                if (radioButtonEliminarFacturas.Checked)
                {
                    DialogResult result = MessageBox.Show("¿Desea Eliminar?", "Eliminar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        EliminarFactura();
                    }
                    else
                    {
                        //Limpiar();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        #region Guardar Factura()
        private void GuardarFactura()
        {
            try
            {
                if (ExisteFactura())
                {
                    MessageBox.Show("El numero de Factura ya esta registrado");
                    this.textBoxCedula_ClienteFactura.Clear();
                }
                else
                {
                    if (this.textBoxCedula_ClienteFactura.Text != "" &&
                        this.textBoxIDMembresiaFactura.Text != "" &&
                        this.textBoxMontoTotalFactura.Text != "" &&
                        this.textBoxEstadoFactura.Text != "")
                    {
                        this.pro.ID_Membresia = this.textBoxIDMembresiaFactura.Text;
                        this.pro.Cedula_Cliente = this.textBoxCedula_ClienteFactura.Text;
                        this.pro.MontoTotal = Convert.ToDecimal(this.textBoxMontoTotalFactura.Text);
                        this.pro.MetodoPago = this.textBoxMetododepago.Text;
                        this.pro.Detalle = this.textBoxDetalleFactura.Text;
                        this.pro.FechaEmision = dateTimePickerFechaEmisionFactura.Value;

                        ProdH = new FacturaHelper(pro);
                        ProdH.GuardarFactura();
                        MessageBox.Show("Factura Almacenado");
                        ListarFacturas();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar la Factura: " + ex.Message);
            }
        }

        #endregion

        #region Metodo Listar Factura()

        private async void ListarFacturas()
        {
            try
            {
                pro = new EntidadFactura();
                pro.opc = 1;

                ProdH = new FacturaHelper(pro);
                table = ProdH.ListarFacturas();

                if (table != null && table.Rows.Count > 0)
                {
                    dataGridViewFacturacion.DataSource = table;
                }
                else
                {
                    MessageBox.Show("La tabla esta vacia o no se inicializo correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion



        private void FrmFacturas_Load(object sender, EventArgs e)
        {

        }

        private void textBoxEstadoFactura_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
