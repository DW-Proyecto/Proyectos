﻿namespace Presentacion
{
    partial class FrmRutinas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioButtonBuscarRutinas = new RadioButton();
            radioButtonActualizarRutinas = new RadioButton();
            radioButtonIngresarRutinas = new RadioButton();
            radioButtonEliminarRutinas = new RadioButton();
            labelIDRutina = new Label();
            labelIDEmpleadoRutina = new Label();
            labelNombreRutina = new Label();
            labelDescripcionRutina = new Label();
            labelDuracionRutina = new Label();
            labelFrecuenciaRutinas = new Label();
            labelDificultadRutina = new Label();
            labelFechaInicioRutina = new Label();
            labelFechaFinRutina = new Label();
            labelEstadoRutinas = new Label();
            textBoxIDRutinas = new TextBox();
            textBoxIDEntrenadorRutinas = new TextBox();
            textBoxNombreRutina = new TextBox();
            textBoxDescripcionRutinas = new TextBox();
            textBoxDuracionRutinas = new TextBox();
            textBoxFrecuenciaRutinas = new TextBox();
            textBoxDificultadRutinas = new TextBox();
            dateTimePickerInicioRutinas = new DateTimePicker();
            dateTimePickerFinRutinas = new DateTimePicker();
            textBoxEstadoRutinas = new TextBox();
            dataGridViewRutinas = new DataGridView();
            buttonAceptarRutinas = new Button();
            buttonCancelarRutinas = new Button();
            labelRutinas = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewRutinas).BeginInit();
            SuspendLayout();
            // 
            // radioButtonBuscarRutinas
            // 
            radioButtonBuscarRutinas.AutoSize = true;
            radioButtonBuscarRutinas.Location = new Point(23, 11);
            radioButtonBuscarRutinas.Name = "radioButtonBuscarRutinas";
            radioButtonBuscarRutinas.Size = new Size(60, 19);
            radioButtonBuscarRutinas.TabIndex = 0;
            radioButtonBuscarRutinas.TabStop = true;
            radioButtonBuscarRutinas.Text = "Buscar";
            radioButtonBuscarRutinas.UseVisualStyleBackColor = true;
            // 
            // radioButtonActualizarRutinas
            // 
            radioButtonActualizarRutinas.AutoSize = true;
            radioButtonActualizarRutinas.Location = new Point(102, 12);
            radioButtonActualizarRutinas.Name = "radioButtonActualizarRutinas";
            radioButtonActualizarRutinas.Size = new Size(77, 19);
            radioButtonActualizarRutinas.TabIndex = 1;
            radioButtonActualizarRutinas.TabStop = true;
            radioButtonActualizarRutinas.Text = "Actualizar";
            radioButtonActualizarRutinas.UseVisualStyleBackColor = true;
            // 
            // radioButtonIngresarRutinas
            // 
            radioButtonIngresarRutinas.AutoSize = true;
            radioButtonIngresarRutinas.Location = new Point(198, 12);
            radioButtonIngresarRutinas.Name = "radioButtonIngresarRutinas";
            radioButtonIngresarRutinas.Size = new Size(67, 19);
            radioButtonIngresarRutinas.TabIndex = 2;
            radioButtonIngresarRutinas.TabStop = true;
            radioButtonIngresarRutinas.Text = "Ingresar";
            radioButtonIngresarRutinas.UseVisualStyleBackColor = true;
            // 
            // radioButtonEliminarRutinas
            // 
            radioButtonEliminarRutinas.AutoSize = true;
            radioButtonEliminarRutinas.Location = new Point(285, 11);
            radioButtonEliminarRutinas.Name = "radioButtonEliminarRutinas";
            radioButtonEliminarRutinas.Size = new Size(68, 19);
            radioButtonEliminarRutinas.TabIndex = 3;
            radioButtonEliminarRutinas.TabStop = true;
            radioButtonEliminarRutinas.Text = "Eliminar";
            radioButtonEliminarRutinas.UseVisualStyleBackColor = true;
            // 
            // labelIDRutina
            // 
            labelIDRutina.AutoSize = true;
            labelIDRutina.Location = new Point(65, 118);
            labelIDRutina.Name = "labelIDRutina";
            labelIDRutina.Size = new Size(57, 15);
            labelIDRutina.TabIndex = 4;
            labelIDRutina.Text = "ID_Rutina";
            // 
            // labelIDEmpleadoRutina
            // 
            labelIDEmpleadoRutina.AutoSize = true;
            labelIDEmpleadoRutina.Location = new Point(65, 167);
            labelIDEmpleadoRutina.Name = "labelIDEmpleadoRutina";
            labelIDEmpleadoRutina.Size = new Size(81, 15);
            labelIDEmpleadoRutina.TabIndex = 5;
            labelIDEmpleadoRutina.Text = "ID_Entrenador";
            // 
            // labelNombreRutina
            // 
            labelNombreRutina.AutoSize = true;
            labelNombreRutina.Location = new Point(65, 211);
            labelNombreRutina.Name = "labelNombreRutina";
            labelNombreRutina.Size = new Size(88, 15);
            labelNombreRutina.TabIndex = 6;
            labelNombreRutina.Text = "Nombre Rutina";
            // 
            // labelDescripcionRutina
            // 
            labelDescripcionRutina.AutoSize = true;
            labelDescripcionRutina.Location = new Point(65, 260);
            labelDescripcionRutina.Name = "labelDescripcionRutina";
            labelDescripcionRutina.Size = new Size(69, 15);
            labelDescripcionRutina.TabIndex = 7;
            labelDescripcionRutina.Text = "Descripcion";
            // 
            // labelDuracionRutina
            // 
            labelDuracionRutina.AutoSize = true;
            labelDuracionRutina.Location = new Point(55, 303);
            labelDuracionRutina.Name = "labelDuracionRutina";
            labelDuracionRutina.Size = new Size(105, 15);
            labelDuracionRutina.TabIndex = 8;
            labelDuracionRutina.Text = "Duracion Semanas";
            // 
            // labelFrecuenciaRutinas
            // 
            labelFrecuenciaRutinas.AutoSize = true;
            labelFrecuenciaRutinas.Location = new Point(65, 337);
            labelFrecuenciaRutinas.Name = "labelFrecuenciaRutinas";
            labelFrecuenciaRutinas.Size = new Size(64, 15);
            labelFrecuenciaRutinas.TabIndex = 9;
            labelFrecuenciaRutinas.Text = "Frecuencia";
            // 
            // labelDificultadRutina
            // 
            labelDificultadRutina.AutoSize = true;
            labelDificultadRutina.Location = new Point(65, 382);
            labelDificultadRutina.Name = "labelDificultadRutina";
            labelDificultadRutina.Size = new Size(88, 15);
            labelDificultadRutina.TabIndex = 10;
            labelDificultadRutina.Text = "Nivel Dificultad";
            // 
            // labelFechaInicioRutina
            // 
            labelFechaInicioRutina.AutoSize = true;
            labelFechaInicioRutina.Location = new Point(65, 425);
            labelFechaInicioRutina.Name = "labelFechaInicioRutina";
            labelFechaInicioRutina.Size = new Size(70, 15);
            labelFechaInicioRutina.TabIndex = 11;
            labelFechaInicioRutina.Text = "Fecha Inicio";
            // 
            // labelFechaFinRutina
            // 
            labelFechaFinRutina.AutoSize = true;
            labelFechaFinRutina.Location = new Point(65, 472);
            labelFechaFinRutina.Name = "labelFechaFinRutina";
            labelFechaFinRutina.Size = new Size(57, 15);
            labelFechaFinRutina.TabIndex = 12;
            labelFechaFinRutina.Text = "Fecha Fin";
            // 
            // labelEstadoRutinas
            // 
            labelEstadoRutinas.AutoSize = true;
            labelEstadoRutinas.Location = new Point(65, 525);
            labelEstadoRutinas.Name = "labelEstadoRutinas";
            labelEstadoRutinas.Size = new Size(42, 15);
            labelEstadoRutinas.TabIndex = 13;
            labelEstadoRutinas.Text = "Estado";
            // 
            // textBoxIDRutinas
            // 
            textBoxIDRutinas.Location = new Point(164, 118);
            textBoxIDRutinas.Name = "textBoxIDRutinas";
            textBoxIDRutinas.Size = new Size(232, 23);
            textBoxIDRutinas.TabIndex = 14;
            textBoxIDRutinas.TextChanged += textBoxIDRutinas_TextChanged;
            // 
            // textBoxIDEntrenadorRutinas
            // 
            textBoxIDEntrenadorRutinas.Location = new Point(166, 164);
            textBoxIDEntrenadorRutinas.Name = "textBoxIDEntrenadorRutinas";
            textBoxIDEntrenadorRutinas.Size = new Size(230, 23);
            textBoxIDEntrenadorRutinas.TabIndex = 15;
            // 
            // textBoxNombreRutina
            // 
            textBoxNombreRutina.Location = new Point(166, 211);
            textBoxNombreRutina.Name = "textBoxNombreRutina";
            textBoxNombreRutina.Size = new Size(230, 23);
            textBoxNombreRutina.TabIndex = 16;
            // 
            // textBoxDescripcionRutinas
            // 
            textBoxDescripcionRutinas.Location = new Point(166, 260);
            textBoxDescripcionRutinas.Name = "textBoxDescripcionRutinas";
            textBoxDescripcionRutinas.Size = new Size(230, 23);
            textBoxDescripcionRutinas.TabIndex = 17;
            // 
            // textBoxDuracionRutinas
            // 
            textBoxDuracionRutinas.Location = new Point(166, 300);
            textBoxDuracionRutinas.Name = "textBoxDuracionRutinas";
            textBoxDuracionRutinas.Size = new Size(231, 23);
            textBoxDuracionRutinas.TabIndex = 18;
            // 
            // textBoxFrecuenciaRutinas
            // 
            textBoxFrecuenciaRutinas.Location = new Point(164, 337);
            textBoxFrecuenciaRutinas.Name = "textBoxFrecuenciaRutinas";
            textBoxFrecuenciaRutinas.Size = new Size(232, 23);
            textBoxFrecuenciaRutinas.TabIndex = 19;
            // 
            // textBoxDificultadRutinas
            // 
            textBoxDificultadRutinas.Location = new Point(164, 379);
            textBoxDificultadRutinas.Name = "textBoxDificultadRutinas";
            textBoxDificultadRutinas.Size = new Size(232, 23);
            textBoxDificultadRutinas.TabIndex = 20;
            // 
            // dateTimePickerInicioRutinas
            // 
            dateTimePickerInicioRutinas.Location = new Point(164, 425);
            dateTimePickerInicioRutinas.Name = "dateTimePickerInicioRutinas";
            dateTimePickerInicioRutinas.Size = new Size(233, 23);
            dateTimePickerInicioRutinas.TabIndex = 21;
            // 
            // dateTimePickerFinRutinas
            // 
            dateTimePickerFinRutinas.Location = new Point(164, 472);
            dateTimePickerFinRutinas.Name = "dateTimePickerFinRutinas";
            dateTimePickerFinRutinas.Size = new Size(233, 23);
            dateTimePickerFinRutinas.TabIndex = 22;
            // 
            // textBoxEstadoRutinas
            // 
            textBoxEstadoRutinas.Location = new Point(166, 525);
            textBoxEstadoRutinas.Name = "textBoxEstadoRutinas";
            textBoxEstadoRutinas.Size = new Size(232, 23);
            textBoxEstadoRutinas.TabIndex = 23;
            // 
            // dataGridViewRutinas
            // 
            dataGridViewRutinas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewRutinas.Location = new Point(447, 164);
            dataGridViewRutinas.Name = "dataGridViewRutinas";
            dataGridViewRutinas.Size = new Size(658, 254);
            dataGridViewRutinas.TabIndex = 24;
            // 
            // buttonAceptarRutinas
            // 
            buttonAceptarRutinas.Location = new Point(136, 584);
            buttonAceptarRutinas.Name = "buttonAceptarRutinas";
            buttonAceptarRutinas.Size = new Size(75, 23);
            buttonAceptarRutinas.TabIndex = 25;
            buttonAceptarRutinas.Text = "Aceptar";
            buttonAceptarRutinas.UseVisualStyleBackColor = true;
            buttonAceptarRutinas.Click += buttonAceptarRutinas_Click;
            // 
            // buttonCancelarRutinas
            // 
            buttonCancelarRutinas.Location = new Point(259, 584);
            buttonCancelarRutinas.Name = "buttonCancelarRutinas";
            buttonCancelarRutinas.Size = new Size(75, 23);
            buttonCancelarRutinas.TabIndex = 26;
            buttonCancelarRutinas.Text = "Cancelar";
            buttonCancelarRutinas.UseVisualStyleBackColor = true;
            // 
            // labelRutinas
            // 
            labelRutinas.AutoSize = true;
            labelRutinas.Font = new Font("Castellar", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelRutinas.Location = new Point(547, 57);
            labelRutinas.Name = "labelRutinas";
            labelRutinas.Size = new Size(122, 25);
            labelRutinas.TabIndex = 27;
            labelRutinas.Text = "Rutinas";
            // 
            // FrmRutinas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(1133, 643);
            Controls.Add(labelRutinas);
            Controls.Add(buttonCancelarRutinas);
            Controls.Add(buttonAceptarRutinas);
            Controls.Add(dataGridViewRutinas);
            Controls.Add(textBoxEstadoRutinas);
            Controls.Add(dateTimePickerFinRutinas);
            Controls.Add(dateTimePickerInicioRutinas);
            Controls.Add(textBoxDificultadRutinas);
            Controls.Add(textBoxFrecuenciaRutinas);
            Controls.Add(textBoxDuracionRutinas);
            Controls.Add(textBoxDescripcionRutinas);
            Controls.Add(textBoxNombreRutina);
            Controls.Add(textBoxIDEntrenadorRutinas);
            Controls.Add(textBoxIDRutinas);
            Controls.Add(labelEstadoRutinas);
            Controls.Add(labelFechaFinRutina);
            Controls.Add(labelFechaInicioRutina);
            Controls.Add(labelDificultadRutina);
            Controls.Add(labelFrecuenciaRutinas);
            Controls.Add(labelDuracionRutina);
            Controls.Add(labelDescripcionRutina);
            Controls.Add(labelNombreRutina);
            Controls.Add(labelIDEmpleadoRutina);
            Controls.Add(labelIDRutina);
            Controls.Add(radioButtonEliminarRutinas);
            Controls.Add(radioButtonIngresarRutinas);
            Controls.Add(radioButtonActualizarRutinas);
            Controls.Add(radioButtonBuscarRutinas);
            Name = "FrmRutinas";
            Text = "Sistema Gimnasio-Rutinas";
            Load += FrmRutinas_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewRutinas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RadioButton radioButtonBuscarRutinas;
        private RadioButton radioButtonActualizarRutinas;
        private RadioButton radioButtonIngresarRutinas;
        private RadioButton radioButtonEliminarRutinas;
        private Label labelIDRutina;
        private Label labelIDEmpleadoRutina;
        private Label labelNombreRutina;
        private Label labelDescripcionRutina;
        private Label labelDuracionRutina;
        private Label labelFrecuenciaRutinas;
        private Label labelDificultadRutina;
        private Label labelFechaInicioRutina;
        private Label labelFechaFinRutina;
        private Label labelEstadoRutinas;
        private TextBox textBoxIDRutinas;
        private TextBox textBoxIDEntrenadorRutinas;
        private TextBox textBoxNombreRutina;
        private TextBox textBoxDescripcionRutinas;
        private TextBox textBoxDuracionRutinas;
        private TextBox textBoxFrecuenciaRutinas;
        private TextBox textBoxDificultadRutinas;
        private DateTimePicker dateTimePickerInicioRutinas;
        private DateTimePicker dateTimePickerFinRutinas;
        private TextBox textBoxEstadoRutinas;
        private DataGridView dataGridViewRutinas;
        private Button buttonAceptarRutinas;
        private Button buttonCancelarRutinas;
        private Label labelRutinas;
    }
}