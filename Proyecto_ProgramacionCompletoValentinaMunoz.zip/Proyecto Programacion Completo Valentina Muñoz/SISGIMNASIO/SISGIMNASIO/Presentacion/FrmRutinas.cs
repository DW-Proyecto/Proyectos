﻿using CapaEntidad;
using CapaNegocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class FrmRutinas : Form
    {
        public FrmRutinas()
        {
            InitializeComponent();
        }
        private EntidadRutinas pro;
        private DataTable table;
        private RutinasHelper ProdH;

        #region Existe Rutina
        private bool ExisteRutina()
        {
            bool Existe = false;
            pro = new EntidadRutinas();
            pro.opc = 2;
            pro.ID_Rutina = this.textBoxIDRutinas.Text;
            ProdH = new RutinasHelper(pro);
            table = new DataTable();

            table = ProdH.ValidaRutina();

            if (table.Rows.Count > 0)
            {
                Existe = true;
            }
            return Existe;
        }

        #endregion 

        #region Guardar Rutina
        private void GuardarRutina()
        {
            try
            {
                // Validar que todos los campos estén llenos
                if (this.textBoxIDRutinas.Text != "" &&
                    this.textBoxIDEntrenadorRutinas.Text != "" &&
                    this.textBoxNombreRutina.Text != "" &&
                    this.textBoxDescripcionRutinas.Text != "" &&
                    this.textBoxDuracionRutinas.Text != "" &&
                    this.textBoxFrecuenciaRutinas.Text != "" &&
                    this.textBoxDificultadRutinas.Text != "")
                {
                    // Validar que la duración sea numérica
                    if (!int.TryParse(this.textBoxDuracionRutinas.Text, out int duracion))
                    {
                        MessageBox.Show("La duración debe ser un número entero.");
                        return;
                    }

                    // Validar fechas: inicio < fin
                    DateTime fechaInicio = dateTimePickerInicioRutinas.Value;
                    DateTime fechaFin = dateTimePickerFinRutinas.Value;

                    if (fechaFin <= fechaInicio)
                    {
                        MessageBox.Show("La fecha de fin debe ser posterior a la de inicio.");
                        return;
                    }
                    this.pro = new EntidadRutinas();
                    this.pro.opc = 3;
                    this.pro.ID_Rutina = this.textBoxIDRutinas.Text;
                    this.pro.ID_Empleados = this.textBoxIDEntrenadorRutinas.Text;
                    this.pro.NombreRutina = this.textBoxNombreRutina.Text;
                    this.pro.Descripcion = this.textBoxDescripcionRutinas.Text;
                    this.pro.NivelDificultad = this.textBoxDificultadRutinas.Text;
                    this.pro.DuracionSemanas = duracion;
                    this.pro.Frecuencia = this.textBoxFrecuenciaRutinas.Text;
                    this.pro.Estado = "Activo";
                    this.pro.FechaInicio = fechaInicio;
                    this.pro.FechaFin = fechaFin;


                    ProdH = new RutinasHelper(pro);
                    ProdH.GuardarRutina();
                    MessageBox.Show("Rutina almacenada correctamente");
                    ListarRutina();
                }
                else
                {
                    MessageBox.Show("Por favor, complete todos los campos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la rutina: " + ex.Message);
            }
        }
        #endregion

        #region

        private void LimpiarCampos()
        {
            textBoxIDRutinas.Text = "";
            textBoxIDEntrenadorRutinas.Text = "";
            textBoxNombreRutina.Text = "";
            textBoxDescripcionRutinas.Text = "";
            textBoxDuracionRutinas.Text = "";
            textBoxDificultadRutinas.Text = "";
            textBoxEstadoRutinas.Text = "";
            dateTimePickerInicioRutinas.Value = new DateTime(2000, 1, 1);
            dateTimePickerFinRutinas.Value = new DateTime(2000, 1, 1);
        }

        #endregion


        #region Metodo Actulizar

        private void ActualizarRutina()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxIDRutinas.Text))
                {
                    MessageBox.Show("Ingrese el ID Rutina que desea actualizar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBoxIDRutinas.Text, out int id))
                {
                    MessageBox.Show("El ID de rutina debe ser un número válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(textBoxIDRutinas.Text) ||
                    string.IsNullOrWhiteSpace(textBoxIDEntrenadorRutinas.Text) ||
                    string.IsNullOrWhiteSpace(textBoxNombreRutina.Text) ||
                    string.IsNullOrWhiteSpace(textBoxDescripcionRutinas.Text) ||
                    string.IsNullOrWhiteSpace(textBoxDuracionRutinas.Text) ||
                    string.IsNullOrWhiteSpace(textBoxDificultadRutinas.Text) ||
                    string.IsNullOrWhiteSpace(textBoxEstadoRutinas.Text))
                {
                    MessageBox.Show("Complete todos los campos para actualizar.", "Campos incompletos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                pro = new EntidadRutinas();
                ProdH = new RutinasHelper(pro);

                pro.opc = 4;
                pro.ID_Rutina = textBoxIDRutinas.Text.Trim();
                pro.ID_Empleados = textBoxIDEntrenadorRutinas.Text.Trim();
                pro.NombreRutina = textBoxNombreRutina.Text.Trim();
                pro.Descripcion = textBoxDescripcionRutinas.Text.Trim();
                pro.DuracionSemanas = int.Parse(textBoxDuracionRutinas.Text.Trim());
                pro.NivelDificultad = textBoxDificultadRutinas.Text.Trim();
                pro.Estado = textBoxEstadoRutinas.Text.Trim();
                pro.FechaInicio = dateTimePickerInicioRutinas.Value;
                pro.FechaFin = dateTimePickerFinRutinas.Value;
                ProdH.ActualizarRutina();

                MessageBox.Show("Rutina actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarRutina();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Método Eliminar

        private void EliminarRutina()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(textBoxIDRutinas.Text))
                {
                    MessageBox.Show("Ingrese el ID de Rutina que desea eliminar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirmacion = MessageBox.Show("¿Está seguro de que desea eliminar esta Rutina", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirmacion == DialogResult.No)
                    return;

                pro = new EntidadRutinas();
                ProdH = new RutinasHelper(pro);

                pro.opc = 5;
                pro.ID_Rutina = textBoxIDRutinas.Text.Trim();

                ProdH.EliminarRutina();

                MessageBox.Show("Rutina eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ListarRutina();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar la Rutina " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion


        #region Metodo Listar Rutinas
        private async void ListarRutina()
        {
            try
            {
                pro = new EntidadRutinas();
                pro.opc = 1;

                ProdH = new RutinasHelper(pro);
                table = ProdH.ListarRutinas();

                if (table != null && table.Rows.Count > 0)
                {
                    dataGridViewRutinas.DataSource = table;
                }
                else
                {
                    MessageBox.Show("La tabla está vacía o no se inicializó correctamente.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        private void buttonAceptarRutinas_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButtonBuscarRutinas.Checked)
                {
                    ListarRutina();
                }
                if (radioButtonIngresarRutinas.Checked)
                {
                    GuardarRutina();
                }
                if (radioButtonActualizarRutinas.Checked)
                {
                    ActualizarRutina();
                }
                if (radioButtonEliminarRutinas.Checked)
                {
                    DialogResult result = MessageBox.Show("¿Desea eliminar?", "Eliminar", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        EliminarRutina();
                    }
                    else
                    {
                        //LimpiarCampos();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void FrmRutinas_Load(object sender, EventArgs e)
        {

        }

        private void textBoxIDRutinas_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
