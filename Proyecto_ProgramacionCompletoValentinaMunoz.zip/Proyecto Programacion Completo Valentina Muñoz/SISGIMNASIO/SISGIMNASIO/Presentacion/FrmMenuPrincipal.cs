namespace Presentacion
{
    public partial class menuStripPrincipal : Form
    {
        public menuStripPrincipal()
        {
            InitializeComponent();
        }

        private void menuClientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmClientes VistaClientes = new FrmClientes();
            //VistaClientes.MdiParent = this;
            VistaClientes.Show();
        }

        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FrmEmpleados VistaEmpleados = new FrmEmpleados();
            VistaEmpleados.Show();
        }

        private void membresiasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmMembresias VistaMembresias = new FrmMembresias();
            VistaMembresias.Show();
        }

        private void facturaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmFacturas VistaFacturas = new FrmFacturas();
            VistaFacturas.Show();
        }

        private void rutinasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRutinas VistaRutinas = new FrmRutinas();
            VistaRutinas.Show();
        }

        private void menuStripPrincipal_Load(object sender, EventArgs e)
        {

        }
    }
}
