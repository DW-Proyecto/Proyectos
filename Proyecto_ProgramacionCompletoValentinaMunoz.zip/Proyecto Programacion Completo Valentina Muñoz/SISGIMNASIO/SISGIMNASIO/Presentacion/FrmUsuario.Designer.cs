﻿namespace Presentacion
{
    partial class FrmUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelUsername = new Label();
            labelContraseña = new Label();
            labelID_EmpleadosUsuario = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            radioButtonBuscarUsuario = new RadioButton();
            radioButtonIngresarUsuario = new RadioButton();
            radioButtonActualizarUsuario = new RadioButton();
            radioButtonEliminarUsuario = new RadioButton();
            buttonAceptarUsuario = new Button();
            dataGridViewUsuario = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewUsuario).BeginInit();
            SuspendLayout();
            // 
            // labelUsername
            // 
            labelUsername.AutoSize = true;
            labelUsername.Location = new Point(12, 51);
            labelUsername.Name = "labelUsername";
            labelUsername.Size = new Size(60, 15);
            labelUsername.TabIndex = 0;
            labelUsername.Text = "Username";
            // 
            // labelContraseña
            // 
            labelContraseña.AutoSize = true;
            labelContraseña.Location = new Point(7, 112);
            labelContraseña.Name = "labelContraseña";
            labelContraseña.Size = new Size(67, 15);
            labelContraseña.TabIndex = 1;
            labelContraseña.Text = "Contraseña";
            // 
            // labelID_EmpleadosUsuario
            // 
            labelID_EmpleadosUsuario.AutoSize = true;
            labelID_EmpleadosUsuario.Location = new Point(7, 175);
            labelID_EmpleadosUsuario.Name = "labelID_EmpleadosUsuario";
            labelID_EmpleadosUsuario.Size = new Size(81, 15);
            labelID_EmpleadosUsuario.TabIndex = 2;
            labelID_EmpleadosUsuario.Text = "ID_Empleados";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(94, 48);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(151, 23);
            textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(94, 109);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(151, 23);
            textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(94, 167);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(151, 23);
            textBox3.TabIndex = 5;
            // 
            // radioButtonBuscarUsuario
            // 
            radioButtonBuscarUsuario.AutoSize = true;
            radioButtonBuscarUsuario.Location = new Point(12, 10);
            radioButtonBuscarUsuario.Name = "radioButtonBuscarUsuario";
            radioButtonBuscarUsuario.Size = new Size(60, 19);
            radioButtonBuscarUsuario.TabIndex = 6;
            radioButtonBuscarUsuario.TabStop = true;
            radioButtonBuscarUsuario.Text = "Buscar";
            radioButtonBuscarUsuario.UseVisualStyleBackColor = true;
            // 
            // radioButtonIngresarUsuario
            // 
            radioButtonIngresarUsuario.AutoSize = true;
            radioButtonIngresarUsuario.Location = new Point(78, 10);
            radioButtonIngresarUsuario.Name = "radioButtonIngresarUsuario";
            radioButtonIngresarUsuario.Size = new Size(67, 19);
            radioButtonIngresarUsuario.TabIndex = 7;
            radioButtonIngresarUsuario.TabStop = true;
            radioButtonIngresarUsuario.Text = "Ingresar";
            radioButtonIngresarUsuario.UseVisualStyleBackColor = true;
            // 
            // radioButtonActualizarUsuario
            // 
            radioButtonActualizarUsuario.AutoSize = true;
            radioButtonActualizarUsuario.Location = new Point(151, 12);
            radioButtonActualizarUsuario.Name = "radioButtonActualizarUsuario";
            radioButtonActualizarUsuario.Size = new Size(77, 19);
            radioButtonActualizarUsuario.TabIndex = 8;
            radioButtonActualizarUsuario.TabStop = true;
            radioButtonActualizarUsuario.Text = "Actualizar";
            radioButtonActualizarUsuario.UseVisualStyleBackColor = true;
            // 
            // radioButtonEliminarUsuario
            // 
            radioButtonEliminarUsuario.AutoSize = true;
            radioButtonEliminarUsuario.Location = new Point(234, 12);
            radioButtonEliminarUsuario.Name = "radioButtonEliminarUsuario";
            radioButtonEliminarUsuario.Size = new Size(68, 19);
            radioButtonEliminarUsuario.TabIndex = 9;
            radioButtonEliminarUsuario.TabStop = true;
            radioButtonEliminarUsuario.Text = "Eliminar";
            radioButtonEliminarUsuario.UseVisualStyleBackColor = true;
            // 
            // buttonAceptarUsuario
            // 
            buttonAceptarUsuario.Location = new Point(127, 222);
            buttonAceptarUsuario.Name = "buttonAceptarUsuario";
            buttonAceptarUsuario.Size = new Size(75, 23);
            buttonAceptarUsuario.TabIndex = 10;
            buttonAceptarUsuario.Text = "Aceptar";
            buttonAceptarUsuario.UseVisualStyleBackColor = true;
            // 
            // dataGridViewUsuario
            // 
            dataGridViewUsuario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewUsuario.Location = new Point(273, 48);
            dataGridViewUsuario.Name = "dataGridViewUsuario";
            dataGridViewUsuario.Size = new Size(664, 272);
            dataGridViewUsuario.TabIndex = 11;
            dataGridViewUsuario.CellContentClick += dataGridView1_CellContentClick;
            // 
            // FrmUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(962, 450);
            Controls.Add(dataGridViewUsuario);
            Controls.Add(buttonAceptarUsuario);
            Controls.Add(radioButtonEliminarUsuario);
            Controls.Add(radioButtonActualizarUsuario);
            Controls.Add(radioButtonIngresarUsuario);
            Controls.Add(radioButtonBuscarUsuario);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(labelID_EmpleadosUsuario);
            Controls.Add(labelContraseña);
            Controls.Add(labelUsername);
            Name = "FrmUsuario";
            Text = "FrmUsuario";
            Load += FrmUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewUsuario).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelUsername;
        private Label labelContraseña;
        private Label labelID_EmpleadosUsuario;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private RadioButton radioButtonBuscarUsuario;
        private RadioButton radioButtonIngresarUsuario;
        private RadioButton radioButtonActualizarUsuario;
        private RadioButton radioButtonEliminarUsuario;
        private Button buttonAceptarUsuario;
        private DataGridView dataGridViewUsuario;
    }
}